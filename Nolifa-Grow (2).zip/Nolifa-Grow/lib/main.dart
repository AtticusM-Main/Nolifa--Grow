import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:uuid/uuid.dart';
import 'services/image_service.dart';
import 'services/inference_service.dart';
import 'services/plant_id_service.dart';
import 'services/history_service.dart';
import 'services/region_service.dart';
import 'services/app_access_service.dart';
import 'screens/login_screen.dart';
import 'screens/access_selection_screen.dart';
import 'screens/result_screen.dart';
import 'screens/about_screen.dart';
import 'screens/history_screen.dart';
import 'screens/map_screen.dart';
import 'screens/plant_database_screen.dart';
import 'screens/ubuntu_network_screen.dart';
import 'screens/yield_predictor_screen.dart';
import 'screens/livestock_network_screen.dart';
import 'screens/livestock_history_screen.dart';
import 'screens/livestock_map_screen.dart';
import 'screens/livestock_guide_screen.dart';
import 'screens/livestock_productivity_screen.dart';
import 'screens/livestock_health_check_screen.dart';
import 'models/diagnosis_record.dart';
import 'models/disease_info.dart';
import 'utils/auth_provider.dart';
import 'utils/app_access_provider.dart';
import 'utils/app_mode_provider.dart';
import 'utils/language_provider.dart';
import 'utils/translations.dart';
import 'widgets/language_toggle.dart';

void main() {
  runApp(const ProviderScope(child: NolifaGrowApp()));
}

class NolifaGrowApp extends ConsumerWidget {
  const NolifaGrowApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'Nolifa Grow',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2D6A4F),
        ),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    if (auth.loading) {
      return const Scaffold(
        backgroundColor: Color(0xFF1B4332),
        body: Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    if (!auth.isLoggedIn) {
      return const LoginScreen();
    }

    final access = ref.watch(appAccessProvider);
    if (access == null) {
      return const AccessSelectionScreen();
    }

    return const HomeScreen();
  }
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final ImageService _imageService = ImageService();
  final InferenceService _inferenceService = InferenceService();
  final PlantIdService _plantIdService = PlantIdService();
  final HistoryService _historyService = HistoryService();
  final RegionService _regionService = RegionService();
  File? _selectedImage;
  bool _isLoading = false;
  bool _modelLoaded = false;
  bool _isOnline = false;

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    await _inferenceService.loadModel();
    setState(() {
      _modelLoaded = true;
    });
  }

  Future<void> _diagnoseImage(File imageFile) async {
    setState(() {
      _isLoading = true;
    });

    final connectivityResult = await Connectivity().checkConnectivity();
    final isOnline = connectivityResult.contains(ConnectivityResult.wifi) ||
        connectivityResult.contains(ConnectivityResult.mobile);
    _isOnline = isOnline;

    Map<String, dynamic>? result;

    if (isOnline) {
      try {
        result = await _plantIdService.diagnose(imageFile);
      } catch (_) {
        result = null;
      }
    }

    if (result == null) {
      result = await _inferenceService.diagnose(imageFile);
      if (result != null) {
        result['offlineMode'] = !isOnline;
      }
    }

    setState(() {
      _isLoading = false;
    });

    if (result != null && mounted) {
      final info = DiseaseDatabase.getInfo(result['label'] ?? 'Unknown');
      final regionKey = await _regionService.getRegion();
      final record = DiagnosisRecord(
        id: const Uuid().v4(),
        label: result['label'] ?? 'Unknown',
        plainName: info.plainName,
        confidence: result['confidence'] ?? '0',
        imagePath: imageFile.path,
        date: DateTime.now(),
        offlineMode: result['offlineMode'] ?? false,
        regionKey: regionKey,
      );
      await _historyService.saveRecord(record);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultScreen(
            image: imageFile,
            label: result!['label'] ?? 'Unknown',
            confidence: result['confidence'] ?? '0',
            offlineMode: result['offlineMode'] ?? false,
          ),
        ),
      );
    }
  }

  void _showImageOptions(String lang) {
    final t = AppTranslations.get;
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(
                Icons.camera_alt,
                color: Color(0xFF2D6A4F),
              ),
              title: Text(t('take_photo', lang)),
              onTap: () async {
                Navigator.pop(context);
                final image = await _imageService.pickFromCamera();
                if (image != null) {
                  setState(() {
                    _selectedImage = image;
                  });
                  await _diagnoseImage(image);
                }
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.photo_library,
                color: Color(0xFF2D6A4F),
              ),
              title: Text(t('choose_gallery', lang)),
              onTap: () async {
                Navigator.pop(context);
                final image = await _imageService.pickFromGallery();
                if (image != null) {
                  setState(() {
                    _selectedImage = image;
                  });
                  await _diagnoseImage(image);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _inferenceService.dispose();
    super.dispose();
  }

  Widget _buildStep(
      String number, String title, String subtitle, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFF2D6A4F),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            icon,
            color: Colors.white38,
            size: 20,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;
    final mode = ref.watch(appModeProvider);
    final access = ref.watch(appAccessProvider) ?? AppAccess.both;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t('app_name', lang),
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          t('tagline', lang),
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.white60,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          t('catchphrase', lang),
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.white38,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const LanguageToggle(),
                      ],
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        PopupMenuButton<String>(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          onSelected: (value) {
                            if (value == 'logout') {
                              ref.read(authProvider.notifier).logout();
                              return;
                            }
                            if (value == 'access') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const AccessSelectionScreen(
                                    allowBack: true,
                                  ),
                                ),
                              );
                              return;
                            }

                            Widget page;
                            switch (value) {
                              case 'history':
                                page = mode == AppMode.livestock
                                    ? const LivestockHistoryScreen()
                                    : const HistoryScreen();
                                break;
                              case 'map':
                                page = mode == AppMode.livestock
                                    ? const LivestockMapScreen()
                                    : const MapScreen();
                                break;
                              case 'ubuntu':
                                page = mode == AppMode.livestock
                                    ? const LivestockNetworkScreen()
                                    : const UbuntuNetworkScreen();
                                break;
                              case 'plants':
                                page = mode == AppMode.livestock
                                    ? const LivestockGuideScreen()
                                    : const PlantDatabaseScreen();
                                break;
                              case 'yield':
                                page = mode == AppMode.livestock
                                    ? const LivestockProductivityScreen()
                                    : const YieldPredictorScreen();
                                break;
                              case 'about':
                                page = const AboutScreen();
                                break;
                              default:
                                return;
                            }
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => page),
                            );
                          },
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: 'history',
                              child: Text(
                                mode == AppMode.livestock
                                    ? t('menu_livestock_history', lang)
                                    : t('menu_history', lang),
                              ),
                            ),
                            PopupMenuItem(
                              value: 'map',
                              child: Text(
                                mode == AppMode.livestock
                                    ? t('menu_livestock_map', lang)
                                    : t('menu_map', lang),
                              ),
                            ),
                            PopupMenuItem(
                              value: 'ubuntu',
                              child: Text(
                                mode == AppMode.livestock
                                    ? t('menu_livestock_network', lang)
                                    : t('menu_ubuntu', lang),
                              ),
                            ),
                            PopupMenuItem(
                              value: 'plants',
                              child: Text(
                                mode == AppMode.livestock
                                    ? t('menu_livestock_guide', lang)
                                    : t('menu_plants', lang),
                              ),
                            ),
                            PopupMenuItem(
                              value: 'yield',
                              child: Text(
                                mode == AppMode.livestock
                                    ? t('menu_livestock_predictor', lang)
                                    : t('menu_yield', lang),
                              ),
                            ),
                            PopupMenuItem(
                              value: 'about',
                              child: Text(t('menu_about', lang)),
                            ),
                            const PopupMenuDivider(),
                            PopupMenuItem(
                              value: 'access',
                              child: Text(t('menu_choose_modules', lang)),
                            ),
                            PopupMenuItem(
                              value: 'logout',
                              child: Text(t('menu_logout', lang)),
                            ),
                          ],
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white12,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.more_vert,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                if (access == AppAccess.both) ...[
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: ToggleButtons(
                            borderRadius: BorderRadius.circular(12),
                            selectedBorderColor: Colors.white24,
                            borderColor: Colors.white12,
                            fillColor: Colors.white24,
                            selectedColor: Colors.white,
                            color: Colors.white70,
                            isSelected: [
                              mode == AppMode.plants,
                              mode == AppMode.livestock,
                            ],
                            onPressed: (idx) {
                              ref.read(appModeProvider.notifier).setMode(
                                    idx == 0
                                        ? AppMode.plants
                                        : AppMode.livestock,
                                  );
                            },
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 10,
                                ),
                                child: Text(t('mode_plants', lang)),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 10,
                                ),
                                child: Text(t('mode_livestock', lang)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                GestureDetector(
                  onTap: mode == AppMode.plants
                      ? (_modelLoaded && !_isLoading ? () => _showImageOptions(lang) : null)
                      : () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const LivestockHealthCheckScreen(),
                            ),
                          );
                        },
                  child: Container(
                    width: double.infinity,
                    height: 220,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2D6A4F),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: Colors.white24,
                        width: 1,
                      ),
                    ),
                    child: mode == AppMode.plants && _isLoading
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const CircularProgressIndicator(
                                color: Colors.white,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                t('analysing', lang),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          )
                        : mode == AppMode.plants && _selectedImage != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(24),
                                child: Image.file(
                                  _selectedImage!,
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  height: double.infinity,
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    mode == AppMode.plants
                                        ? Icons.camera_alt_outlined
                                        : Icons.health_and_safety_outlined,
                                    color: Colors.white54,
                                    size: 56,
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    mode == AppMode.plants
                                        ? t('tap_to_scan', lang)
                                        : t('livestock_home_action', lang),
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 16,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    mode == AppMode.plants
                                        ? t('camera_or_gallery', lang)
                                        : t('livestock_home_action_sub', lang),
                                    style: const TextStyle(
                                      color: Colors.white38,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                  ),
                ),
                const SizedBox(height: 32),
                Text(
                  t('how_it_works', lang),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                _buildStep(
                  '1',
                  mode == AppMode.plants
                      ? t('step1_title', lang)
                      : t('livestock_step1_title', lang),
                  mode == AppMode.plants
                      ? t('step1_sub', lang)
                      : t('livestock_step1_sub', lang),
                  mode == AppMode.plants ? Icons.camera_alt : Icons.pets,
                ),
                const SizedBox(height: 12),
                _buildStep(
                  '2',
                  mode == AppMode.plants
                      ? t('step2_title', lang)
                      : t('livestock_step2_title', lang),
                  mode == AppMode.plants
                      ? t('step2_sub', lang)
                      : t('livestock_step2_sub', lang),
                  mode == AppMode.plants ? Icons.search : Icons.health_and_safety,
                ),
                const SizedBox(height: 12),
                _buildStep(
                  '3',
                  mode == AppMode.plants
                      ? t('step3_title', lang)
                      : t('livestock_step3_title', lang),
                  mode == AppMode.plants
                      ? t('step3_sub', lang)
                      : t('livestock_step3_sub', lang),
                  mode == AppMode.plants ? Icons.healing : Icons.map_outlined,
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
