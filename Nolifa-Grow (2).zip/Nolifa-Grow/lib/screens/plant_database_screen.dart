import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/plant_species.dart';
import '../services/plant_database_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'plant_detail_screen.dart';

class PlantDatabaseScreen extends ConsumerStatefulWidget {
  const PlantDatabaseScreen({super.key});

  @override
  ConsumerState<PlantDatabaseScreen> createState() =>
      _PlantDatabaseScreenState();
}

class _PlantDatabaseScreenState extends ConsumerState<PlantDatabaseScreen> {
  final PlantDatabaseService _service = PlantDatabaseService();
  List<PlantSpecies> _plants = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final plants = await _service.loadKznPlants();
    if (!mounted) return;
    setState(() {
      _plants = plants;
      _loading = false;
    });
  }

  List<PlantSpecies> _filtered() {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _plants;

    return _plants.where((p) {
      final hay = [
        p.commonNameEn,
        p.commonNameZu,
        p.scientificName ?? '',
        ...p.tags,
      ].join(' ').toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final filtered = _filtered();

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('plants_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: TextField(
                    onChanged: (v) => setState(() => _query = v),
                    style: const TextStyle(color: Colors.white),
                    cursorColor: Colors.white,
                    decoration: InputDecoration(
                      hintText: t('plants_search_hint', lang),
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: Colors.white10,
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Colors.white54,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: filtered.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Text(
                              t('plants_empty', lang),
                              style: const TextStyle(color: Colors.white54),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: filtered.length,
                          itemBuilder: (context, index) {
                            final plant = filtered[index];
                            final title = lang == 'zu'
                                ? plant.commonNameZu
                                : plant.commonNameEn;
                            final subtitle = lang == 'zu'
                                ? plant.commonNameEn
                                : plant.commonNameZu;

                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                color: Colors.white10,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ListTile(
                                title: Text(
                                  title,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text(
                                  subtitle,
                                  style: const TextStyle(
                                    color: Colors.white54,
                                    fontSize: 12,
                                  ),
                                ),
                                trailing: const Icon(
                                  Icons.chevron_right,
                                  color: Colors.white24,
                                ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          PlantDetailScreen(plant: plant),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
