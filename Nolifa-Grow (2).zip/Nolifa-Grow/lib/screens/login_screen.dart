import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../utils/auth_provider.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _pin = TextEditingController();

  bool _createAccount = false;
  bool _submitting = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _submit(String lang) async {
    final t = AppTranslations.get;
    final phone = _phone.text.trim();
    final pin = _pin.text.trim();
    final name = _name.text.trim();

    if (phone.isEmpty || pin.isEmpty || (_createAccount && name.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('login_missing', lang))),
      );
      return;
    }

    if (pin.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('login_pin_short', lang))),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      if (_createAccount) {
        await ref.read(authProvider.notifier).register(
              name: name,
              phone: phone,
              pin: pin,
            );
      } else {
        await ref.read(authProvider.notifier).login(phone: phone, pin: pin);
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('login_failed', lang))),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t('login_title', lang),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      t('login_subtitle', lang),
                      style: const TextStyle(color: Colors.white60),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              _createAccount
                                  ? t('login_create_account', lang)
                                  : t('login_have_account', lang),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Switch(
                            value: _createAccount,
                            onChanged: (v) => setState(() => _createAccount = v),
                            activeColor: const Color(0xFF2D6A4F),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (_createAccount) ...[
                      _label(t('login_name', lang)),
                      const SizedBox(height: 6),
                      _field(
                        controller: _name,
                        hint: t('login_name_hint', lang),
                      ),
                      const SizedBox(height: 12),
                    ],
                    _label(t('login_phone', lang)),
                    const SizedBox(height: 6),
                    _field(
                      controller: _phone,
                      hint: t('login_phone_hint', lang),
                      keyboardType: TextInputType.phone,
                    ),
                    const SizedBox(height: 12),
                    _label(t('login_pin', lang)),
                    const SizedBox(height: 6),
                    _field(
                      controller: _pin,
                      hint: t('login_pin_hint', lang),
                      keyboardType: TextInputType.number,
                      obscureText: true,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _submitting ? null : () => _submit(lang),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2D6A4F),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          _submitting
                              ? t('saving', lang)
                              : (_createAccount
                                  ? t('login_register', lang)
                                  : t('login_login', lang)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      t('login_note', lang),
                      style: const TextStyle(color: Colors.white38, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(String text) {
    return Text(text, style: const TextStyle(color: Colors.white54, fontSize: 12));
  }

  Widget _field({
    required TextEditingController controller,
    required String hint,
    TextInputType? keyboardType,
    bool obscureText = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38),
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
      ),
    );
  }
}

