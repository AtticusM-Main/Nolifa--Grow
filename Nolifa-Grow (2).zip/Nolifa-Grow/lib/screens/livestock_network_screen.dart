import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/region_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'livestock_health_check_screen.dart';
import 'livestock_map_screen.dart';
import 'livestock_market_listings_screen.dart';
import 'livestock_productivity_screen.dart';
import 'livestock_guide_screen.dart';
import 'vet_request_screen.dart';

class LivestockNetworkScreen extends ConsumerStatefulWidget {
  const LivestockNetworkScreen({super.key});

  @override
  ConsumerState<LivestockNetworkScreen> createState() => _LivestockNetworkScreenState();
}

class _LivestockNetworkScreenState extends ConsumerState<LivestockNetworkScreen> {
  final RegionService _regionService = RegionService();
  String? _regionKey;

  @override
  void initState() {
    super.initState();
    _loadRegion();
  }

  Future<void> _loadRegion() async {
    final r = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _regionKey = r;
    });
  }

  Future<void> _pickRegion(String lang) async {
    final t = AppTranslations.get;
    final selected = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final key in KznRegions.keys)
              ListTile(
                title: Text(KznRegions.label(key, lang)),
                trailing: _regionKey == key ? const Icon(Icons.check) : null,
                onTap: () => Navigator.pop(context, key),
              ),
          ],
        ),
      ),
    );

    if (selected == null) return;
    await _regionService.setRegion(selected);
    if (!mounted) return;
    setState(() {
      _regionKey = selected;
    });
  }

  Widget _card({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: const Color(0xFF2D6A4F),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white38),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t('ubuntu_region', lang),
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _regionKey == null
                              ? t('region_skip', lang)
                              : t(_regionKey!, lang),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () => _pickRegion(lang),
                    child: Text(t('ubuntu_set_region', lang)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              t('livestock_subtitle', lang),
              style: const TextStyle(color: Colors.white60, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _card(
                    icon: Icons.health_and_safety,
                    title: t('livestock_check', lang),
                    subtitle: t('livestock_check_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LivestockHealthCheckScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _card(
                    icon: Icons.map_outlined,
                    title: t('livestock_map', lang),
                    subtitle: t('livestock_map_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const LivestockMapScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _card(
                    icon: Icons.swap_horiz,
                    title: t('livestock_market', lang),
                    subtitle: t('livestock_market_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LivestockMarketListingsScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _card(
                    icon: Icons.auto_graph,
                    title: t('livestock_predictor', lang),
                    subtitle: t('livestock_predictor_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const LivestockProductivityScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _card(
                    icon: Icons.menu_book,
                    title: t('livestock_guide', lang),
                    subtitle: t('livestock_guide_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const LivestockGuideScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _card(
                    icon: Icons.medical_services_outlined,
                    title: t('livestock_vet', lang),
                    subtitle: t('livestock_vet_sub', lang),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const VetRequestScreen()),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
