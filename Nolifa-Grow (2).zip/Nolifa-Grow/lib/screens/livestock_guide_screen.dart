import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_condition_info.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class LivestockGuideScreen extends ConsumerStatefulWidget {
  const LivestockGuideScreen({super.key});

  @override
  ConsumerState<LivestockGuideScreen> createState() => _LivestockGuideScreenState();
}

class _LivestockGuideScreenState extends ConsumerState<LivestockGuideScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final all = LivestockConditionDatabase.conditions.values.toList()
      ..sort((a, b) => a.plainName.compareTo(b.plainName));
    final filtered = _query.trim().isEmpty
        ? all
        : all
            .where(
              (c) =>
                  c.plainName.toLowerCase().contains(_query.toLowerCase()) ||
                  c.description.toLowerCase().contains(_query.toLowerCase()),
            )
            .toList();

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_guide', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              onChanged: (v) => setState(() => _query = v),
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: t('livestock_search', lang),
                hintStyle: const TextStyle(color: Colors.white38),
                prefixIcon: const Icon(Icons.search, color: Colors.white54),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: filtered.isEmpty
                  ? Center(
                      child: Text(
                        t('livestock_search_empty', lang),
                        style: const TextStyle(color: Colors.white54),
                      ),
                    )
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (context, i) {
                        final c = filtered[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: Colors.white12),
                          ),
                          child: ExpansionTile(
                            collapsedIconColor: Colors.white54,
                            iconColor: Colors.white,
                            title: Text(
                              c.plainName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                            ),
                            subtitle: Text(
                              c.severity,
                              style: const TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                            children: [
                              Text(
                                c.description,
                                style: const TextStyle(color: Colors.white70, fontSize: 13),
                              ),
                              const SizedBox(height: 10),
                              _section(t('livestock_signs', lang), c.signs),
                              const SizedBox(height: 10),
                              _section(t('livestock_treatment', lang), c.treatment),
                              const SizedBox(height: 10),
                              _section(t('livestock_prevention', lang), c.prevention),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, List<String> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
        ),
        const SizedBox(height: 6),
        for (final s in items.take(6))
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(
              '• $s',
              style: const TextStyle(color: Colors.white70, fontSize: 12),
            ),
          ),
      ],
    );
  }
}

