import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/livestock_condition_info.dart';
import '../models/vet_request.dart';
import '../services/region_service.dart';
import '../services/vet_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class VetRequestScreen extends ConsumerStatefulWidget {
  final String? species;
  final String? conditionKey;

  const VetRequestScreen({super.key, this.species, this.conditionKey});

  @override
  ConsumerState<VetRequestScreen> createState() => _VetRequestScreenState();
}

class _VetRequestScreenState extends ConsumerState<VetRequestScreen> {
  final VetService _service = VetService();
  final RegionService _regionService = RegionService();

  final TextEditingController _name = TextEditingController();
  final TextEditingController _contact = TextEditingController();
  final TextEditingController _message = TextEditingController();

  String? _regionKey;
  String _species = 'cattle';
  String _conditionKey = 'healthy';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _species = widget.species ?? 'cattle';
    _conditionKey = widget.conditionKey ?? 'healthy';
    _init();
  }

  Future<void> _init() async {
    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _regionKey = region;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _contact.dispose();
    _message.dispose();
    super.dispose();
  }

  Future<void> _submit(String lang) async {
    final t = AppTranslations.get;
    if (_name.text.trim().isEmpty || _contact.text.trim().isEmpty || _message.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('vet_missing', lang))),
      );
      return;
    }

    setState(() => _saving = true);

    final req = VetRequest(
      id: const Uuid().v4(),
      species: _species,
      conditionKey: _conditionKey,
      regionKey: _regionKey ?? 'other',
      notes: _message.text.trim(),
      createdAt: DateTime.now(),
    );

    await _service.submitRequest(req);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final speciesOptions = <String, String>{
      'cattle': t('ls_cattle', lang),
      'goats': t('ls_goats', lang),
      'sheep': t('ls_sheep', lang),
      'poultry': t('ls_poultry', lang),
    };

    final conditions = LivestockConditionDatabase.conditions.values.toList()
      ..sort((a, b) => a.plainName.compareTo(b.plainName));

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('vet_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('vet_subtitle', lang),
              style: const TextStyle(color: Colors.white70, height: 1.5),
            ),
            const SizedBox(height: 14),
            _Field(
              label: t('agronomist_name', lang),
              controller: _name,
              hint: t('agronomist_name_hint', lang),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('agronomist_contact', lang),
              controller: _contact,
              hint: t('agronomist_contact_hint', lang),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String?>(
                  dropdownColor: const Color(0xFF1B4332),
                  value: _regionKey,
                  isExpanded: true,
                  hint: Text(
                    t('region_question', lang),
                    style: const TextStyle(color: Colors.white54),
                  ),
                  iconEnabledColor: Colors.white54,
                  items: [
                    DropdownMenuItem<String?>(
                      value: null,
                      child: Text(t('region_skip', lang)),
                    ),
                    ...KznRegions.keys.map(
                      (key) => DropdownMenuItem<String?>(
                        value: key,
                        child: Text(KznRegions.label(key, lang)),
                      ),
                    ),
                  ],
                  onChanged: (value) => setState(() => _regionKey = value),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: const Color(0xFF1B4332),
                  value: _species,
                  isExpanded: true,
                  iconEnabledColor: Colors.white54,
                  items: speciesOptions.entries
                      .map(
                        (e) => DropdownMenuItem<String>(
                          value: e.key,
                          child: Text(e.value),
                        ),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => _species = v),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: const Color(0xFF1B4332),
                  value: _conditionKey,
                  isExpanded: true,
                  iconEnabledColor: Colors.white54,
                  items: conditions
                      .map(
                        (c) => DropdownMenuItem<String>(
                          value: c.key,
                          child: Text(c.plainName),
                        ),
                      )
                      .toList(),
                  onChanged: (v) => setState(() => _conditionKey = v),
                ),
              ),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('vet_message', lang),
              controller: _message,
              hint: t('vet_message_hint', lang),
              maxLines: 5,
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : () => _submit(lang),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2D6A4F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(
                  _saving ? t('saving', lang) : t('vet_submit', lang),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final int maxLines;

  const _Field({
    required this.label,
    required this.hint,
    required this.controller,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: maxLines,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Colors.white38),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
            ),
          ),
        ),
      ],
    );
  }
}

