import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/livestock_market_listing.dart';
import '../services/livestock_market_service.dart';
import '../services/region_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class LivestockMarketFormScreen extends ConsumerStatefulWidget {
  final LivestockMarketListing? existing;

  const LivestockMarketFormScreen({super.key, this.existing});

  @override
  ConsumerState<LivestockMarketFormScreen> createState() => _LivestockMarketFormScreenState();
}

class _LivestockMarketFormScreenState extends ConsumerState<LivestockMarketFormScreen> {
  final LivestockMarketService _service = LivestockMarketService();
  final RegionService _regionService = RegionService();

  late final TextEditingController _title;
  late final TextEditingController _description;

  String _species = 'cattle';
  String _listingType = 'offer';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.existing?.title ?? '');
    _description = TextEditingController(text: widget.existing?.description ?? '');
    _species = widget.existing?.species ?? 'cattle';
    _listingType = widget.existing?.listingType ?? 'offer';
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _save(String lang) async {
    final t = AppTranslations.get;
    if (_title.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('livestock_market_title_required', lang))),
      );
      return;
    }

    setState(() => _saving = true);
    final regionKey = (await _regionService.getRegion()) ?? 'other';

    final listing = LivestockMarketListing(
      id: widget.existing?.id ?? const Uuid().v4(),
      title: _title.text.trim(),
      species: _species,
      listingType: _listingType,
      description: _description.text.trim(),
      regionKey: regionKey,
      createdAt: widget.existing?.createdAt ?? DateTime.now(),
    );

    await _service.upsertListing(listing);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final speciesOptions = <String, String>{
      'cattle': t('ls_cattle', lang),
      'goats': t('ls_goats', lang),
      'sheep': t('ls_sheep', lang),
      'poultry': t('ls_poultry', lang),
    };

    final typeOptions = <String, String>{
      'offer': t('livestock_market_offer', lang),
      'need': t('livestock_market_need', lang),
      'swap': t('livestock_market_swap', lang),
    };

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          widget.existing == null ? t('livestock_market_new', lang) : t('livestock_market_edit', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            _label(t('livestock_market_type', lang)),
            const SizedBox(height: 6),
            DropdownButtonFormField<String>(
              value: _listingType,
              dropdownColor: const Color(0xFF1B4332),
              items: typeOptions.entries
                  .map(
                    (e) => DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value, style: const TextStyle(color: Colors.white)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _listingType = v ?? 'offer'),
              decoration: _inputDecoration(),
            ),
            const SizedBox(height: 12),
            _label(t('ls_species', lang)),
            const SizedBox(height: 6),
            DropdownButtonFormField<String>(
              value: _species,
              dropdownColor: const Color(0xFF1B4332),
              items: speciesOptions.entries
                  .map(
                    (e) => DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value, style: const TextStyle(color: Colors.white)),
                    ),
                  )
                  .toList(),
              onChanged: (v) => setState(() => _species = v ?? 'cattle'),
              decoration: _inputDecoration(),
            ),
            const SizedBox(height: 12),
            _label(t('livestock_market_title', lang)),
            const SizedBox(height: 6),
            TextField(
              controller: _title,
              style: const TextStyle(color: Colors.white),
              decoration: _inputDecoration().copyWith(
                hintText: t('livestock_market_title_hint', lang),
                hintStyle: const TextStyle(color: Colors.white38),
              ),
            ),
            const SizedBox(height: 12),
            _label(t('livestock_market_description', lang)),
            const SizedBox(height: 6),
            TextField(
              controller: _description,
              maxLines: 5,
              style: const TextStyle(color: Colors.white),
              decoration: _inputDecoration().copyWith(
                hintText: t('livestock_market_description_hint', lang),
                hintStyle: const TextStyle(color: Colors.white38),
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton(
              onPressed: _saving ? null : () => _save(lang),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2D6A4F),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: Text(_saving ? t('saving', lang) : t('save', lang)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _label(String text) {
    return Text(text, style: const TextStyle(color: Colors.white54, fontSize: 12));
  }

  InputDecoration _inputDecoration() {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white10,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
      ),
    );
  }
}

