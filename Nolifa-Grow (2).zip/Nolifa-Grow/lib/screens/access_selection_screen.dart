import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/app_access_service.dart';
import '../utils/app_access_provider.dart';
import '../utils/app_mode_provider.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class AccessSelectionScreen extends ConsumerWidget {
  final bool allowBack;

  const AccessSelectionScreen({super.key, this.allowBack = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    Future<void> choose(AppAccess access) async {
      await ref.read(appAccessProvider.notifier).setAccess(access);
      if (access == AppAccess.plantsOnly) {
        await ref.read(appModeProvider.notifier).setMode(AppMode.plants);
      } else if (access == AppAccess.livestockOnly) {
        await ref.read(appModeProvider.notifier).setMode(AppMode.livestock);
      }
      if (context.mounted) {
        if (allowBack) {
          Navigator.pop(context);
        }
      }
    }

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: allowBack,
        title: Text(
          t('access_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('access_subtitle', lang),
              style: const TextStyle(color: Colors.white70, height: 1.4),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _option(
                    title: t('access_plants', lang),
                    subtitle: t('access_plants_sub', lang),
                    icon: Icons.local_florist,
                    onTap: () => choose(AppAccess.plantsOnly),
                  ),
                  const SizedBox(height: 12),
                  _option(
                    title: t('access_livestock', lang),
                    subtitle: t('access_livestock_sub', lang),
                    icon: Icons.pets,
                    onTap: () => choose(AppAccess.livestockOnly),
                  ),
                  const SizedBox(height: 12),
                  _option(
                    title: t('access_both', lang),
                    subtitle: t('access_both_sub', lang),
                    icon: Icons.dashboard_customize,
                    onTap: () => choose(AppAccess.both),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _option({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: const Color(0xFF2D6A4F),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white60, fontSize: 12),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white38),
          ],
        ),
      ),
    );
  }
}

