import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/plant_species.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class PlantDetailScreen extends ConsumerWidget {
  final PlantSpecies plant;

  const PlantDetailScreen({super.key, required this.plant});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final title = lang == 'zu' ? plant.commonNameZu : plant.commonNameEn;
    final otherName = lang == 'zu' ? plant.commonNameEn : plant.commonNameZu;
    final description = lang == 'zu' ? plant.descriptionZu : plant.descriptionEn;
    final uses = lang == 'zu' ? plant.usesZu : plant.usesEn;
    final cautions = lang == 'zu' ? plant.cautionsZu : plant.cautionsEn;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              otherName,
              style: const TextStyle(color: Colors.white54),
            ),
            if ((plant.scientificName ?? '').trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                '${t('plant_scientific', lang)}: ${plant.scientificName}',
                style: const TextStyle(color: Colors.white70),
              ),
            ],
            const SizedBox(height: 16),
            _Card(
              title: t('plant_about', lang),
              child: Text(
                description,
                style: const TextStyle(
                  color: Colors.white70,
                  height: 1.6,
                ),
              ),
            ),
            const SizedBox(height: 12),
            _Card(
              title: t('plant_uses', lang),
              child: uses.isEmpty
                  ? Text(
                      t('plant_none', lang),
                      style: const TextStyle(color: Colors.white54),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: uses
                          .map(
                            (u) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                '• $u',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  height: 1.4,
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
            ),
            const SizedBox(height: 12),
            _Card(
              title: t('plant_cautions', lang),
              child: cautions.isEmpty
                  ? Text(
                      t('plant_none', lang),
                      style: const TextStyle(color: Colors.white54),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: cautions
                          .map(
                            (c) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                '• $c',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  height: 1.4,
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final Widget child;

  const _Card({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

