import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/agronomist_request.dart';
import '../services/agronomist_service.dart';
import '../services/region_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class AgronomistRequestScreen extends ConsumerStatefulWidget {
  final String? diagnosisLabel;
  final String? diagnosisConfidence;
  final String? imagePath;

  const AgronomistRequestScreen({
    super.key,
    this.diagnosisLabel,
    this.diagnosisConfidence,
    this.imagePath,
  });

  @override
  ConsumerState<AgronomistRequestScreen> createState() =>
      _AgronomistRequestScreenState();
}

class _AgronomistRequestScreenState
    extends ConsumerState<AgronomistRequestScreen> {
  final AgronomistService _service = AgronomistService();
  final RegionService _regionService = RegionService();

  final TextEditingController _name = TextEditingController();
  final TextEditingController _contact = TextEditingController();
  final TextEditingController _message = TextEditingController();

  String? _regionKey;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _regionKey = region;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _contact.dispose();
    _message.dispose();
    super.dispose();
  }

  Future<void> _submit(String lang) async {
    final t = AppTranslations.get;

    if (_name.text.trim().isEmpty ||
        _contact.text.trim().isEmpty ||
        _message.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('agronomist_missing', lang))),
      );
      return;
    }

    setState(() {
      _saving = true;
    });

    final req = AgronomistRequest(
      id: const Uuid().v4(),
      name: _name.text.trim(),
      contact: _contact.text.trim(),
      regionKey: _regionKey,
      message: _message.text.trim(),
      diagnosisLabel: widget.diagnosisLabel,
      diagnosisConfidence: widget.diagnosisConfidence,
      imagePath: widget.imagePath,
      createdAt: DateTime.now(),
    );

    await _service.submitRequest(req);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final diagText = widget.diagnosisLabel == null
        ? null
        : '${widget.diagnosisLabel} (${widget.diagnosisConfidence ?? ''}%)';

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('agronomist_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('agronomist_subtitle', lang),
              style: const TextStyle(color: Colors.white70, height: 1.5),
            ),
            if (diagText != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white24),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.medical_information_outlined,
                      color: Colors.white70,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '${t('agronomist_diagnosis', lang)}: $diagText',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (widget.imagePath != null &&
                File(widget.imagePath!).existsSync()) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(
                  File(widget.imagePath!),
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ],
            const SizedBox(height: 14),
            _Field(
              label: t('agronomist_name', lang),
              controller: _name,
              hint: t('agronomist_name_hint', lang),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('agronomist_contact', lang),
              controller: _contact,
              hint: t('agronomist_contact_hint', lang),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String?>(
                  dropdownColor: const Color(0xFF1B4332),
                  value: _regionKey,
                  isExpanded: true,
                  hint: Text(
                    t('region_question', lang),
                    style: const TextStyle(color: Colors.white54),
                  ),
                  iconEnabledColor: Colors.white54,
                  items: [
                    DropdownMenuItem<String?>(
                      value: null,
                      child: Text(t('region_skip', lang)),
                    ),
                    ...KznRegions.keys.map(
                      (key) => DropdownMenuItem<String?>(
                        value: key,
                        child: Text(KznRegions.label(key, lang)),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _regionKey = value;
                    });
                  },
                ),
              ),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('agronomist_message', lang),
              controller: _message,
              hint: t('agronomist_message_hint', lang),
              maxLines: 5,
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : () => _submit(lang),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2D6A4F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(
                  _saving ? t('saving', lang) : t('agronomist_submit', lang),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final int maxLines;

  const _Field({
    required this.label,
    required this.hint,
    required this.controller,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            maxLines: maxLines,
            style: const TextStyle(color: Colors.white),
            cursorColor: Colors.white,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white38),
              border: InputBorder.none,
            ),
          ),
        ],
      ),
    );
  }
}

