import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_condition_info.dart';
import '../models/livestock_health_record.dart';
import '../services/livestock_history_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class LivestockPoint {
  final String regionKey;
  final LatLng location;
  final String conditionKey;
  final String severity;
  final DateTime date;

  const LivestockPoint({
    required this.regionKey,
    required this.location,
    required this.conditionKey,
    required this.severity,
    required this.date,
  });
}

class LivestockMapScreen extends ConsumerStatefulWidget {
  const LivestockMapScreen({super.key});

  @override
  ConsumerState<LivestockMapScreen> createState() => _LivestockMapScreenState();
}

class _LivestockMapScreenState extends ConsumerState<LivestockMapScreen> {
  final MapController _mapController = MapController();
  final LivestockHistoryService _historyService = LivestockHistoryService();

  late final List<LivestockPoint> _points;
  _HexCell? _selectedCell;
  String _selectedFilter = 'all';
  bool _hexView = true;
  int _timeWindowDays = 30;

  @override
  void initState() {
    super.initState();
    _points = [];
    _loadFromHistory();
  }

  Future<void> _loadFromHistory() async {
    final history = await _historyService.getHistory();
    final points = <LivestockPoint>[];
    for (final LivestockHealthRecord r in history) {
      final regionKey = r.regionKey ?? 'other';
      final center = _regionCenter(regionKey);
      if (center == null) continue;
      final jittered = _jitter(center, seed: r.id.hashCode);
      final info = LivestockConditionDatabase.getInfo(r.conditionKey);
      points.add(
        LivestockPoint(
          regionKey: regionKey,
          location: jittered,
          conditionKey: r.conditionKey,
          severity: info.severityColor,
          date: r.date,
        ),
      );
    }

    if (!mounted) return;
    setState(() {
      _points
        ..clear()
        ..addAll(points);
      _selectedCell = null;
    });
  }

  LatLng? _regionCenter(String regionKey) {
    switch (regionKey) {
      case 'greater_durban':
        return const LatLng(-29.8587, 31.0218);
      case 'midlands':
        return const LatLng(-29.6167, 30.3833);
      case 'north_coast':
        return const LatLng(-29.4, 31.2);
      case 'south_coast':
        return const LatLng(-30.2, 30.8);
      case 'zululand':
        return const LatLng(-28.75, 31.88);
      case 'northern_kzn':
        return const LatLng(-27.8, 32.1);
      case 'other':
        return const LatLng(-29.0, 31.0);
      default:
        return null;
    }
  }

  LatLng _jitter(LatLng center, {required int seed}) {
    final r = math.Random(seed);
    final latJ = (r.nextDouble() - 0.5) * 0.12;
    final lonJ = (r.nextDouble() - 0.5) * 0.12;
    return LatLng(center.latitude + latJ, center.longitude + lonJ);
  }

  Color _getColor(String severity) {
    switch (severity) {
      case 'green':
        return const Color(0xFF2D6A4F);
      case 'orange':
        return const Color(0xFFE07B39);
      case 'red':
        return const Color(0xFFD62828);
      case 'none':
        return Colors.white.withOpacity(0.04);
      default:
        return Colors.grey;
    }
  }

  List<LivestockPoint> get _filteredPoints {
    final now = DateTime.now();
    final windowed = _timeWindowDays <= 0
        ? _points
        : _points.where((p) => now.difference(p.date).inDays <= _timeWindowDays);

    if (_selectedFilter == 'all') return windowed.toList();
    return windowed.where((p) => p.severity == _selectedFilter).toList();
  }

  int _countBySeverity(String severity) {
    return _filteredPoints.where((p) => p.severity == severity).length;
  }

  double _latStepForZoom(double zoom) {
    final z = zoom.clamp(6.0, 16.0);
    final scale = 1 << (z.round() - 7).clamp(0, 9);
    return (0.45 / scale).clamp(0.01, 0.45);
  }

  double _lonStepForZoom(double zoom, double lat) {
    final latStep = _latStepForZoom(zoom);
    final cosLat = math.cos(lat.abs() * 0.017453292519943295);
    final base = latStep / (cosLat == 0 ? 1 : cosLat);
    return base.clamp(latStep * 0.8, latStep * 1.6);
  }

  List<_HexCell> _buildHexCells(double zoom) {
    if (_filteredPoints.isEmpty) return const [];

    final avgLat = _filteredPoints
            .map((p) => p.location.latitude)
            .reduce((a, b) => a + b) /
        _filteredPoints.length;

    final latStep = _latStepForZoom(zoom);
    final lonStep = _lonStepForZoom(zoom, avgLat);

    final Map<String, List<LivestockPoint>> grouped = {};
    for (final p in _filteredPoints) {
      final row = (p.location.latitude / latStep).round();
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      final col = ((p.location.longitude + offset) / lonStep).round();
      final key = '$row:$col';
      grouped.putIfAbsent(key, () => []).add(p);
    }

    final cells = <_HexCell>[];
    grouped.forEach((key, points) {
      final parts = key.split(':');
      final row = int.parse(parts[0]);
      final col = int.parse(parts[1]);
      final offset = row.isOdd ? lonStep / 2 : 0.0;

      final center = LatLng(row * latStep, (col * lonStep) - offset);
      final severity = _aggregateSeverity(points);
      final outbreaks = _topOutbreaks(points);

      cells.add(
        _HexCell(
          center: center,
          points: points,
          severity: severity,
          topOutbreaks: outbreaks,
        ),
      );
    });

    cells.sort((a, b) => b.points.length.compareTo(a.points.length));
    return cells;
  }

  List<Polygon> _buildHexGridPolygons(double zoom) {
    final center = _mapController.camera.center;
    final latStep = _latStepForZoom(zoom);
    final lonStep = _lonStepForZoom(zoom, center.latitude);

    final grouped = <String, List<LivestockPoint>>{};
    for (final p in _filteredPoints) {
      final row = (p.location.latitude / latStep).round();
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      final col = ((p.location.longitude + offset) / lonStep).round();
      final key = '$row:$col';
      grouped.putIfAbsent(key, () => []).add(p);
    }

    final row0 = (center.latitude / latStep).round();
    final offset0 = row0.isOdd ? lonStep / 2 : 0.0;
    final col0 = ((center.longitude + offset0) / lonStep).round();

    final z = zoom.clamp(6.0, 16.0);
    final half = z <= 7.5
        ? 8
        : z <= 10.5
            ? 10
            : 12;

    final polygons = <Polygon>[];
    for (var row = row0 - half; row <= row0 + half; row++) {
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      for (var col = col0 - half; col <= col0 + half; col++) {
        final key = '$row:$col';
        final points = grouped[key] ?? const <LivestockPoint>[];
        final severity = points.isEmpty ? 'none' : _aggregateSeverity(points);
        final color = points.isEmpty
            ? Colors.white.withOpacity(0.03)
            : _getColor(severity).withOpacity(
                (0.10 + (points.length.clamp(1, 6) * 0.03)).clamp(0.10, 0.30),
              );

        final border = points.isEmpty
            ? Colors.white.withOpacity(0.08)
            : _getColor(severity).withOpacity(0.40);

        final centerLat = row * latStep;
        final centerLon = (col * lonStep) - offset;
        final centerPoint = LatLng(centerLat, centerLon);
        final hexPoints = _hexPolygonPoints(
          center: centerPoint,
          latStep: latStep,
          lonStep: lonStep,
        );

        polygons.add(
          Polygon(
            points: hexPoints,
            color: color,
            borderColor: border,
            borderStrokeWidth: points.isEmpty ? 0.8 : 1.4,
          ),
        );
      }
    }

    return polygons;
  }

  List<LatLng> _hexPolygonPoints({
    required LatLng center,
    required double latStep,
    required double lonStep,
  }) {
    final rLat = (latStep / 2) * 0.92;
    final rLon = (lonStep / 2) * 0.92;
    final points = <LatLng>[];

    for (var i = 0; i < 6; i++) {
      final angle = (60.0 * i - 30.0) * 0.017453292519943295;
      final lat = center.latitude + (rLat * math.sin(angle));
      final lon = center.longitude + (rLon * math.cos(angle));
      points.add(LatLng(lat, lon));
    }
    return points;
  }

  String _aggregateSeverity(List<LivestockPoint> points) {
    if (points.any((p) => p.severity == 'red')) return 'red';
    if (points.any((p) => p.severity == 'orange')) return 'orange';
    return 'green';
  }

  List<_OutbreakStat> _topOutbreaks(List<LivestockPoint> points) {
    final counts = <String, int>{};
    for (final p in points) {
      counts[p.conditionKey] = (counts[p.conditionKey] ?? 0) + 1;
    }
    final list = counts.entries
        .map((e) => _OutbreakStat(conditionKey: e.key, count: e.value))
        .toList();
    list.sort((a, b) => b.count.compareTo(a.count));
    return list.take(3).toList();
  }

  void _zoomTo(LatLng center, double zoom) {
    _mapController.move(center, zoom);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;
    final zoom = (_mapController.camera.zoom == 0) ? 7.0 : _mapController.camera.zoom;
    final cells = _hexView ? _buildHexCells(zoom) : const <_HexCell>[];
    final hexGridPolygons = _hexView ? _buildHexGridPolygons(zoom) : const <Polygon>[];

    const initial = LatLng(-29.0, 31.0);

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_map_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            tooltip: t('map_refresh', lang),
            onPressed: _loadFromHistory,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: t('map_hex_toggle', lang),
            onPressed: () {
              setState(() {
                _hexView = !_hexView;
                _selectedCell = null;
              });
            },
            icon: Icon(_hexView ? Icons.grid_view : Icons.location_on),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t('livestock_map_subtitle', lang),
                  style: const TextStyle(color: Colors.white60, fontSize: 12),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _filterChip(
                      label: '${t('filter_all', lang)} (${_filteredPoints.length})',
                      selected: _selectedFilter == 'all',
                      onTap: () => setState(() => _selectedFilter = 'all'),
                    ),
                    const SizedBox(width: 8),
                    _filterChip(
                      label: '${t('map_healthy', lang)} (${_countBySeverity('green')})',
                      selected: _selectedFilter == 'green',
                      onTap: () => setState(() => _selectedFilter = 'green'),
                    ),
                    const SizedBox(width: 8),
                    _filterChip(
                      label: '${t('map_moderate', lang)} (${_countBySeverity('orange')})',
                      selected: _selectedFilter == 'orange',
                      onTap: () => setState(() => _selectedFilter = 'orange'),
                    ),
                    const SizedBox(width: 8),
                    _filterChip(
                      label: '${t('map_urgent', lang)} (${_countBySeverity('red')})',
                      selected: _selectedFilter == 'red',
                      onTap: () => setState(() => _selectedFilter = 'red'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _timeChip(
                      label: t('map_time_24h', lang),
                      selected: _timeWindowDays == 1,
                      onTap: () => setState(() => _timeWindowDays = 1),
                    ),
                    const SizedBox(width: 8),
                    _timeChip(
                      label: t('map_time_7d', lang),
                      selected: _timeWindowDays == 7,
                      onTap: () => setState(() => _timeWindowDays = 7),
                    ),
                    const SizedBox(width: 8),
                    _timeChip(
                      label: t('map_time_30d', lang),
                      selected: _timeWindowDays == 30,
                      onTap: () => setState(() => _timeWindowDays = 30),
                    ),
                    const SizedBox(width: 8),
                    _timeChip(
                      label: t('map_time_all', lang),
                      selected: _timeWindowDays == 0,
                      onTap: () => setState(() => _timeWindowDays = 0),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: initial,
                initialZoom: 7,
                minZoom: 6,
                maxZoom: 17,
                onTap: (_, __) => setState(() => _selectedCell = null),
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.nolifagrow.nolifa_grow',
                ),
                if (_hexView)
                  PolygonLayer(
                    polygons: hexGridPolygons,
                  ),
                if (!_hexView)
                  MarkerLayer(
                    markers: _filteredPoints
                        .map(
                          (p) => Marker(
                            point: p.location,
                            width: 44,
                            height: 44,
                            child: GestureDetector(
                              onTap: () {
                                final targetZoom = (zoom + 1.2).clamp(7.0, 16.0);
                                _zoomTo(p.location, targetZoom);
                              },
                              child: Icon(
                                Icons.location_on,
                                color: _getColor(p.severity),
                                size: 34,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                if (_hexView)
                  MarkerLayer(
                    markers: cells
                        .map(
                          (c) => Marker(
                            point: c.center,
                            width: 48,
                            height: 48,
                            child: GestureDetector(
                              onTap: () {
                                final targetZoom = (zoom + 1.0).clamp(7.0, 16.0);
                                _zoomTo(c.center, targetZoom);
                                setState(() => _selectedCell = c);
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: _getColor(c.severity).withOpacity(0.55),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.6),
                                    width: 1.2,
                                  ),
                                ),
                                child: Center(
                                  child: Text(
                                    c.points.length.toString(),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
              ],
            ),
          ),
          if (_selectedCell != null) _buildDetails(lang),
        ],
      ),
    );
  }

  Widget _filterChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? Colors.white24 : Colors.white10,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white12),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : Colors.white70,
            fontSize: 11,
            fontWeight: selected ? FontWeight.bold : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _timeChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? Colors.white24 : Colors.white10,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white12),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : Colors.white70,
            fontSize: 11,
            fontWeight: selected ? FontWeight.bold : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildDetails(String lang) {
    final t = AppTranslations.get;
    final cell = _selectedCell!;
    final top = cell.topOutbreaks;

    LivestockConditionInfo? topInfo;
    if (top.isNotEmpty) {
      topInfo = LivestockConditionDatabase.getInfo(top.first.conditionKey);
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: const BoxDecoration(
        color: Color(0xFF102A20),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(18),
          topRight: Radius.circular(18),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  t('map_outbreak_details', lang),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              Text(
                '${t('map_cases', lang)}: ${cell.points.length}',
                style: const TextStyle(color: Colors.white60, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            t('map_top_outbreaks', lang),
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          for (final s in top)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      LivestockConditionDatabase.getInfo(s.conditionKey).plainName,
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    s.count.toString(),
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
          if (topInfo != null) ...[
            const SizedBox(height: 10),
            Text(
              t('map_remedy', lang),
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            for (final step in topInfo.treatment.take(3))
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '• $step',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ),
          ],
          const SizedBox(height: 6),
          Text(
            t('map_legend', lang),
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _legendDot(Colors.white.withOpacity(0.15), t('map_density_low', lang)),
              const SizedBox(width: 10),
              _legendDot(Colors.white.withOpacity(0.25), t('map_density_med', lang)),
              const SizedBox(width: 10),
              _legendDot(Colors.white.withOpacity(0.35), t('map_density_high', lang)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color c, String label) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: c, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
      ],
    );
  }
}

class _HexCell {
  final LatLng center;
  final List<LivestockPoint> points;
  final String severity;
  final List<_OutbreakStat> topOutbreaks;

  const _HexCell({
    required this.center,
    required this.points,
    required this.severity,
    required this.topOutbreaks,
  });
}

class _OutbreakStat {
  final String conditionKey;
  final int count;

  const _OutbreakStat({required this.conditionKey, required this.count});
}
