import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/yield_prediction.dart';
import '../services/history_service.dart';
import '../services/region_service.dart';
import '../services/yield_predictor_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class YieldPredictorScreen extends ConsumerStatefulWidget {
  const YieldPredictorScreen({super.key});

  @override
  ConsumerState<YieldPredictorScreen> createState() =>
      _YieldPredictorScreenState();
}

class _CropMetric {
  final int days;
  final double yieldKg;

  const _CropMetric({required this.days, required this.yieldKg});
}

extension on _YieldPredictorScreenState {
  String _estimatedRevenue() {
    final result = _result;
    if (result == null) return '0';
    final pricePerKg = double.tryParse(_price.text.trim()) ?? 0;
    final revenue = result.estimatedYieldKg * pricePerKg;
    return revenue.toStringAsFixed(0);
  }
}

class _YieldPredictorScreenState extends ConsumerState<YieldPredictorScreen> {
  final YieldPredictorService _service = YieldPredictorService();
  final HistoryService _historyService = HistoryService();
  final RegionService _regionService = RegionService();

  final TextEditingController _area = TextEditingController();
  final TextEditingController _price = TextEditingController();

  SoilType _soil = SoilType.loam;
  HumidityLevel _humidity = HumidityLevel.medium;
  String _cropId = YieldPredictorService.crops.first.id;
  DiseaseRiskLevel? _overrideRisk;
  String? _regionKey;
  bool _loading = true;
  YieldPredictionResult? _result;
  Map<String, _CropMetric> _recommendMetrics = {};

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final defaults = await _service.loadDefaults();
    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _soil = defaults.$1;
      _humidity = defaults.$2;
      _area.text = defaults.$3.toStringAsFixed(0);
      _cropId = defaults.$4;
      _price.text = defaults.$5.toStringAsFixed(0);
      _regionKey = region;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _area.dispose();
    _price.dispose();
    super.dispose();
  }

  Future<void> _predict(String lang) async {
    final t = AppTranslations.get;
    final areaM2 = double.tryParse(_area.text.trim()) ?? 0;
    final pricePerKg = double.tryParse(_price.text.trim()) ?? 0;
    if (areaM2 <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('yield_area_error', lang))),
      );
      return;
    }
    if (pricePerKg < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('yield_price_error', lang))),
      );
      return;
    }

    final history = await _historyService.getHistory();
    final now = DateTime.now();
    final result = _service.predict(
      cropId: _cropId,
      areaM2: areaM2,
      soilType: _soil,
      humidity: _humidity,
      now: now,
      history: history,
      overrideDiseaseRisk: _overrideRisk,
    );

    await _service.saveDefaults(
      soil: _soil,
      humidity: _humidity,
      areaM2: areaM2,
      cropId: _cropId,
      pricePerKg: pricePerKg,
    );

    if (!mounted) return;
    final metrics = <String, _CropMetric>{};
    for (final c in result.recommendedToPlantNow) {
      final r = _service.predict(
        cropId: c.id,
        areaM2: areaM2,
        soilType: _soil,
        humidity: _humidity,
        now: now,
        history: history,
        overrideDiseaseRisk: result.diseaseRisk,
      );
      metrics[c.id] = _CropMetric(
        days: r.estimatedDaysToHarvest,
        yieldKg: r.estimatedYieldKg,
      );
    }

    setState(() {
      _result = result;
      _recommendMetrics = metrics;
    });
  }

  Future<void> _applyScenario({
    required SoilType soil,
    required HumidityLevel humidity,
    required String cropId,
    required double areaM2,
    required DiseaseRiskLevel? overrideRisk,
    required String lang,
  }) async {
    setState(() {
      _soil = soil;
      _humidity = humidity;
      _cropId = cropId;
      _area.text = areaM2.toStringAsFixed(0);
      _overrideRisk = overrideRisk;
      _result = null;
    });
    await _predict(lang);
  }

  String _soilLabel(String lang, SoilType soil) {
    final t = AppTranslations.get;
    switch (soil) {
      case SoilType.sandy:
        return t('soil_sandy', lang);
      case SoilType.loam:
        return t('soil_loam', lang);
      case SoilType.clay:
        return t('soil_clay', lang);
      case SoilType.coastalSand:
        return t('soil_coastal_sand', lang);
      case SoilType.alluvial:
        return t('soil_alluvial', lang);
    }
  }

  String _humidityLabel(String lang, HumidityLevel humidity) {
    final t = AppTranslations.get;
    switch (humidity) {
      case HumidityLevel.low:
        return t('humidity_low', lang);
      case HumidityLevel.medium:
        return t('humidity_medium', lang);
      case HumidityLevel.high:
        return t('humidity_high', lang);
    }
  }

  String _riskLabel(String lang, DiseaseRiskLevel risk) {
    final t = AppTranslations.get;
    switch (risk) {
      case DiseaseRiskLevel.low:
        return t('risk_low', lang);
      case DiseaseRiskLevel.medium:
        return t('risk_medium', lang);
      case DiseaseRiskLevel.high:
        return t('risk_high', lang);
    }
  }

  Color _riskColor(DiseaseRiskLevel risk) {
    switch (risk) {
      case DiseaseRiskLevel.low:
        return const Color(0xFF2D6A4F);
      case DiseaseRiskLevel.medium:
        return const Color(0xFFE07B39);
      case DiseaseRiskLevel.high:
        return const Color(0xFFD62828);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final regionText = _regionKey == null
        ? t('region_skip', lang)
        : KznRegions.label(_regionKey!, lang);

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('yield_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    t('yield_subtitle', lang),
                    style: const TextStyle(color: Colors.white70, height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t('yield_scenarios', lang),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _ScenarioChip(
                              label: t('yield_scenario_durban', lang),
                              onTap: () => _applyScenario(
                                soil: SoilType.coastalSand,
                                humidity: HumidityLevel.high,
                                cropId: 'tomato',
                                areaM2: 20,
                                overrideRisk: DiseaseRiskLevel.high,
                                lang: lang,
                              ),
                            ),
                            _ScenarioChip(
                              label: t('yield_scenario_midlands', lang),
                              onTap: () => _applyScenario(
                                soil: SoilType.loam,
                                humidity: HumidityLevel.low,
                                cropId: 'cabbage',
                                areaM2: 30,
                                overrideRisk: DiseaseRiskLevel.low,
                                lang: lang,
                              ),
                            ),
                            _ScenarioChip(
                              label: t('yield_scenario_zululand', lang),
                              onTap: () => _applyScenario(
                                soil: SoilType.sandy,
                                humidity: HumidityLevel.medium,
                                cropId: 'imbuya',
                                areaM2: 15,
                                overrideRisk: DiseaseRiskLevel.medium,
                                lang: lang,
                              ),
                            ),
                            _ScenarioChip(
                              label: t('yield_scenario_reset', lang),
                              onTap: () {
                                setState(() {
                                  _overrideRisk = null;
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  _Card(
                    child: Column(
                      children: [
                        _RowLabel(
                          label: t('ubuntu_region', lang),
                          value: regionText,
                        ),
                        const SizedBox(height: 12),
                        _Dropdown<DiseaseRiskLevel?>(
                          label: t('yield_risk_override', lang),
                          value: _overrideRisk,
                          items: const [
                            null,
                            DiseaseRiskLevel.low,
                            DiseaseRiskLevel.medium,
                            DiseaseRiskLevel.high,
                          ],
                          itemLabel: (v) {
                            if (v == null) return t('yield_risk_auto', lang);
                            return _riskLabel(lang, v);
                          },
                          onChanged: (v) => setState(() => _overrideRisk = v),
                        ),
                        const SizedBox(height: 12),
                        _Dropdown<SoilType>(
                          label: t('yield_soil', lang),
                          value: _soil,
                          items: SoilType.values,
                          itemLabel: (v) => _soilLabel(lang, v),
                          onChanged: (v) => setState(() => _soil = v),
                        ),
                        const SizedBox(height: 12),
                        _Dropdown<HumidityLevel>(
                          label: t('yield_humidity', lang),
                          value: _humidity,
                          items: HumidityLevel.values,
                          itemLabel: (v) => _humidityLabel(lang, v),
                          onChanged: (v) => setState(() => _humidity = v),
                        ),
                        const SizedBox(height: 12),
                        _Dropdown<String>(
                          label: t('yield_crop', lang),
                          value: _cropId,
                          items: YieldPredictorService.crops.map((c) => c.id),
                          itemLabel: (id) {
                            final crop = YieldPredictorService.crops
                                .firstWhere((c) => c.id == id);
                            return lang == 'zu' ? crop.nameZu : crop.nameEn;
                          },
                          onChanged: (v) => setState(() => _cropId = v),
                        ),
                        const SizedBox(height: 12),
                        _TextField(
                          label: t('yield_area', lang),
                          controller: _area,
                          hint: t('yield_area_hint', lang),
                        ),
                        const SizedBox(height: 12),
                        _TextField(
                          label: t('yield_price', lang),
                          controller: _price,
                          hint: t('yield_price_hint', lang),
                        ),
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => _predict(lang),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF2D6A4F),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                            icon: const Icon(Icons.insights_outlined),
                            label: Text(
                              t('yield_predict', lang),
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (_result != null) ...[
                    const SizedBox(height: 14),
                    _Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t('yield_results', lang),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _RowLabel(
                            label: t('yield_days', lang),
                            value:
                                '${_result!.estimatedDaysToHarvest} ${t('yield_days_unit', lang)}',
                          ),
                          const SizedBox(height: 8),
                          _RowLabel(
                            label: t('yield_weight', lang),
                            value:
                                '${_result!.estimatedYieldKg} ${t('yield_kg', lang)}',
                          ),
                          const SizedBox(height: 8),
                          _RowLabel(
                            label: t('yield_revenue', lang),
                            value: '${_estimatedRevenue()} ${t('yield_currency', lang)}',
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Text(
                                '${t('yield_risk', lang)}: ',
                                style: const TextStyle(color: Colors.white70),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: _riskColor(_result!.diseaseRisk)
                                      .withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(
                                    color: _riskColor(_result!.diseaseRisk)
                                        .withOpacity(0.35),
                                  ),
                                ),
                                child: Text(
                                  _riskLabel(lang, _result!.diseaseRisk),
                                  style: TextStyle(
                                    color: _riskColor(_result!.diseaseRisk),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    _Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            t('yield_recommend', lang),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          const SizedBox(height: 10),
                          ..._result!.recommendedToPlantNow.map((c) {
                            final name = lang == 'zu' ? c.nameZu : c.nameEn;
                            final metric = _recommendMetrics[c.id];
                            final detail = metric == null
                                ? ''
                                : ' — ${metric.days}${t('yield_days_short', lang)}, ${metric.yieldKg}${t('yield_kg_short', lang)}';
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Text(
                                '• $name$detail',
                                style: const TextStyle(color: Colors.white70),
                              ),
                            );
                          }),
                          if (_result!.recommendedToPlantNow.isEmpty)
                            Text(
                              t('yield_recommend_empty', lang),
                              style: const TextStyle(color: Colors.white54),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      t('yield_note', lang),
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 11,
                        height: 1.5,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;

  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24),
      ),
      child: child,
    );
  }
}

class _RowLabel extends StatelessWidget {
  final String label;
  final String value;

  const _RowLabel({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(label, style: const TextStyle(color: Colors.white54)),
        ),
        const SizedBox(width: 12),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _Dropdown<T> extends StatelessWidget {
  final String label;
  final T value;
  final Iterable<T> items;
  final String Function(T value) itemLabel;
  final ValueChanged<T> onChanged;

  const _Dropdown({
    required this.label,
    required this.value,
    required this.items,
    required this.itemLabel,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          DropdownButtonHideUnderline(
            child: DropdownButton<T>(
              dropdownColor: const Color(0xFF1B4332),
              value: value,
              isExpanded: true,
              iconEnabledColor: Colors.white54,
              items: items
                  .map(
                    (i) => DropdownMenuItem<T>(
                      value: i,
                      child: Text(
                        itemLabel(i),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                onChanged(v);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TextField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;

  const _TextField({
    required this.label,
    required this.hint,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: const TextStyle(color: Colors.white),
            cursorColor: Colors.white,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white38),
              border: InputBorder.none,
            ),
          ),
        ],
      ),
    );
  }
}

class _ScenarioChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _ScenarioChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white10,
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}
