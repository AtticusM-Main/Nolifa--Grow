import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_productivity_prediction.dart';
import '../services/livestock_productivity_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class LivestockProductivityScreen extends ConsumerStatefulWidget {
  const LivestockProductivityScreen({super.key});

  @override
  ConsumerState<LivestockProductivityScreen> createState() => _LivestockProductivityScreenState();
}

class _LivestockProductivityScreenState extends ConsumerState<LivestockProductivityScreen> {
  final LivestockProductivityService _service = LivestockProductivityService();

  String _species = 'cattle';
  String _feedQuality = 'medium';
  String _diseasePressure = 'medium';
  int _humidity = 75;
  int _herdSize = 10;
  double _avgWeightKg = 250;
  double _pricePerKg = 55;

  late final TextEditingController _herdController;
  late final TextEditingController _avgWeightController;
  late final TextEditingController _priceController;

  LivestockProductivityPrediction? _prediction;

  @override
  void initState() {
    super.initState();
    _herdController = TextEditingController(text: _herdSize.toString());
    _avgWeightController = TextEditingController(text: _avgWeightKg.toStringAsFixed(0));
    _priceController = TextEditingController(text: _pricePerKg.toStringAsFixed(0));
  }

  @override
  void dispose() {
    _herdController.dispose();
    _avgWeightController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _calculate() {
    setState(() {
      _prediction = _service.predict(
        species: _species,
        herdSize: _herdSize.clamp(1, 1000),
        avgWeightKg: _avgWeightKg.clamp(1, 2000),
        feedQuality: _feedQuality,
        humidityPct: _humidity.clamp(10, 100),
        diseasePressure: _diseasePressure,
        pricePerKg: _pricePerKg.clamp(0, 9999),
      );
    });
  }

  Color _riskColor(String name) {
    switch (name) {
      case 'green':
        return const Color(0xFF2D6A4F);
      case 'orange':
        return const Color(0xFFE07B39);
      case 'red':
        return const Color(0xFFD62828);
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final speciesOptions = <String, String>{
      'cattle': t('ls_cattle', lang),
      'goats': t('ls_goats', lang),
      'sheep': t('ls_sheep', lang),
      'poultry': t('ls_poultry', lang),
    };

    final feedOptions = <String, String>{
      'low': t('livestock_feed_low', lang),
      'medium': t('livestock_feed_medium', lang),
      'high': t('livestock_feed_high', lang),
    };

    final pressureOptions = <String, String>{
      'low': t('livestock_pressure_low', lang),
      'medium': t('livestock_pressure_medium', lang),
      'high': t('livestock_pressure_high', lang),
    };

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_predictor', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            t('livestock_predictor_intro', lang),
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const SizedBox(height: 12),
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _label(t('ls_species', lang)),
                const SizedBox(height: 6),
                _dropdown(
                  value: _species,
                  items: speciesOptions,
                  onChanged: (v) => setState(() => _species = v),
                ),
                const SizedBox(height: 12),
                _label(t('livestock_herd_size', lang)),
                const SizedBox(height: 6),
                _numberField(
                  controller: _herdController,
                  onChanged: (v) => setState(() => _herdSize = int.tryParse(v) ?? _herdSize),
                ),
                const SizedBox(height: 12),
                _label(t('livestock_avg_weight', lang)),
                const SizedBox(height: 6),
                _numberField(
                  controller: _avgWeightController,
                  onChanged: (v) => setState(() => _avgWeightKg = double.tryParse(v) ?? _avgWeightKg),
                ),
                const SizedBox(height: 12),
                _label(t('livestock_price_per_kg', lang)),
                const SizedBox(height: 6),
                _numberField(
                  controller: _priceController,
                  onChanged: (v) => setState(() => _pricePerKg = double.tryParse(v) ?? _pricePerKg),
                ),
                const SizedBox(height: 12),
                _label(t('livestock_feed_quality', lang)),
                const SizedBox(height: 6),
                _dropdown(
                  value: _feedQuality,
                  items: feedOptions,
                  onChanged: (v) => setState(() => _feedQuality = v),
                ),
                const SizedBox(height: 12),
                _label(t('livestock_humidity', lang)),
                const SizedBox(height: 6),
                Slider(
                  value: _humidity.toDouble(),
                  min: 40,
                  max: 95,
                  divisions: 11,
                  label: '$_humidity%',
                  onChanged: (v) => setState(() => _humidity = v.round()),
                ),
                const SizedBox(height: 6),
                _label(t('livestock_disease_pressure', lang)),
                const SizedBox(height: 6),
                _dropdown(
                  value: _diseasePressure,
                  items: pressureOptions,
                  onChanged: (v) => setState(() => _diseasePressure = v),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _calculate,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2D6A4F),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text(t('livestock_calculate', lang)),
                ),
              ],
            ),
          ),
          if (_prediction != null) ...[
            const SizedBox(height: 12),
            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _prediction!.headline,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: _riskColor(_prediction!.riskColor),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _prediction!.riskLevel,
                        style: TextStyle(
                          color: _riskColor(_prediction!.riskColor),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '${t('livestock_days_to_market', lang)}: ${_prediction!.daysToMarket}',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${t('livestock_expected_gain', lang)}: ${_prediction!.expectedGainKg.toStringAsFixed(1)} kg',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${t('livestock_expected_revenue', lang)}: R${_prediction!.expectedRevenue.toStringAsFixed(0)}',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    t('livestock_recommendations', lang),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  for (final s in _prediction!.recommendations)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text('• $s', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: child,
    );
  }

  Widget _label(String text) {
    return Text(text, style: const TextStyle(color: Colors.white54, fontSize: 12));
  }

  Widget _dropdown({
    required String value,
    required Map<String, String> items,
    required ValueChanged<String> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      dropdownColor: const Color(0xFF1B4332),
      items: items.entries
          .map(
            (e) => DropdownMenuItem(
              value: e.key,
              child: Text(e.value, style: const TextStyle(color: Colors.white)),
            ),
          )
          .toList(),
      onChanged: (v) => onChanged(v ?? value),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
      ),
    );
  }

  Widget _numberField({
    required TextEditingController controller,
    required ValueChanged<String> onChanged,
  }) {
    return TextField(
      keyboardType: TextInputType.number,
      style: const TextStyle(color: Colors.white),
      controller: controller,
      onChanged: onChanged,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
        ),
      ),
    );
  }
}
