import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/barter_listing.dart';
import '../services/barter_service.dart';
import '../services/region_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';

class BarterListingFormScreen extends ConsumerStatefulWidget {
  final BarterListing? existing;

  const BarterListingFormScreen({super.key, this.existing});

  @override
  ConsumerState<BarterListingFormScreen> createState() =>
      _BarterListingFormScreenState();
}

class _BarterListingFormScreenState
    extends ConsumerState<BarterListingFormScreen> {
  final BarterService _service = BarterService();
  final RegionService _regionService = RegionService();

  final TextEditingController _offer = TextEditingController();
  final TextEditingController _want = TextEditingController();
  final TextEditingController _notes = TextEditingController();
  final TextEditingController _contact = TextEditingController();

  String? _regionKey;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final existing = widget.existing;
    if (existing != null) {
      _offer.text = existing.offer;
      _want.text = existing.want;
      _notes.text = existing.notes ?? '';
      _contact.text = existing.contact ?? '';
      setState(() {
        _regionKey = existing.regionKey;
      });
      return;
    }

    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _regionKey = region;
    });
  }

  @override
  void dispose() {
    _offer.dispose();
    _want.dispose();
    _notes.dispose();
    _contact.dispose();
    super.dispose();
  }

  Future<void> _save(String lang) async {
    final t = AppTranslations.get;

    if (_offer.text.trim().isEmpty || _want.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(t('barter_missing', lang))),
      );
      return;
    }

    setState(() {
      _saving = true;
    });

    final existing = widget.existing;
    final now = DateTime.now();
    final listing = BarterListing(
      id: existing?.id ?? const Uuid().v4(),
      offer: _offer.text.trim(),
      want: _want.text.trim(),
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      contact: _contact.text.trim().isEmpty ? null : _contact.text.trim(),
      regionKey: _regionKey,
      languageCode: existing?.languageCode ?? lang,
      createdAt: existing?.createdAt ?? now,
    );

    await _service.upsertListing(listing);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          widget.existing == null
              ? t('barter_add', lang)
              : t('barter_edit', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _Field(
              label: t('barter_offer', lang),
              controller: _offer,
              hint: t('barter_offer_hint', lang),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('barter_want', lang),
              controller: _want,
              hint: t('barter_want_hint', lang),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String?>(
                  dropdownColor: const Color(0xFF1B4332),
                  value: _regionKey,
                  isExpanded: true,
                  hint: Text(
                    t('region_question', lang),
                    style: const TextStyle(color: Colors.white54),
                  ),
                  iconEnabledColor: Colors.white54,
                  items: [
                    DropdownMenuItem<String?>(
                      value: null,
                      child: Text(t('region_skip', lang)),
                    ),
                    ...KznRegions.keys.map(
                      (key) => DropdownMenuItem<String?>(
                        value: key,
                        child: Text(KznRegions.label(key, lang)),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _regionKey = value;
                    });
                  },
                ),
              ),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('barter_contact', lang),
              controller: _contact,
              hint: t('barter_contact_hint', lang),
            ),
            const SizedBox(height: 12),
            _Field(
              label: t('barter_notes', lang),
              controller: _notes,
              hint: t('barter_notes_hint', lang),
              maxLines: 4,
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : () => _save(lang),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2D6A4F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text(
                  _saving ? t('saving', lang) : t('save', lang),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final int maxLines;

  const _Field({
    required this.label,
    required this.hint,
    required this.controller,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            maxLines: maxLines,
            style: const TextStyle(color: Colors.white),
            cursorColor: Colors.white,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white38),
              border: InputBorder.none,
            ),
          ),
        ],
      ),
    );
  }
}
