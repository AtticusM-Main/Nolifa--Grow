import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/barter_listing.dart';
import '../services/barter_service.dart';
import '../services/region_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'barter_listing_form_screen.dart';
import 'barter_listing_detail_screen.dart';

class BarterListingsScreen extends ConsumerStatefulWidget {
  const BarterListingsScreen({super.key});

  @override
  ConsumerState<BarterListingsScreen> createState() =>
      _BarterListingsScreenState();
}

class _BarterListingsScreenState extends ConsumerState<BarterListingsScreen> {
  final BarterService _service = BarterService();
  final RegionService _regionService = RegionService();

  List<BarterListing> _listings = [];
  bool _loading = true;
  bool _myRegionOnly = false;
  String? _regionKey;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final listings = await _service.getListings();
    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _listings = listings;
      _regionKey = region;
      _loading = false;
    });
  }

  List<BarterListing> _filtered() {
    if (!_myRegionOnly || _regionKey == null) return _listings;
    return _listings.where((l) => l.regionKey == _regionKey).toList();
  }

  Future<void> _createOrEdit({
    BarterListing? listing,
  }) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => BarterListingFormScreen(existing: listing),
      ),
    );
    if (saved == true) {
      await _load();
    }
  }

  Future<void> _confirmDelete(String lang, BarterListing listing) async {
    final t = AppTranslations.get;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t('barter_delete', lang)),
        content: Text(t('barter_delete_confirm', lang)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(t('cancel', lang)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              t('delete', lang),
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _service.deleteListing(listing.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final filtered = _filtered();

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('barter_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: _loading
                ? null
                : () {
                    setState(() {
                      _myRegionOnly = !_myRegionOnly;
                    });
                  },
            tooltip: t('barter_my_region', lang),
            icon: Icon(
              _myRegionOnly ? Icons.filter_alt : Icons.filter_alt_outlined,
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : filtered.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.swap_horiz,
                          color: Colors.white24,
                          size: 70,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          t('barter_empty_title', lang),
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          t('barter_empty_sub', lang),
                          style: const TextStyle(color: Colors.white38),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final listing = filtered[index];
                    final region = listing.regionKey == null
                        ? t('region_skip', lang)
                        : KznRegions.label(listing.regionKey!, lang);

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  BarterListingDetailScreen(listing: listing),
                            ),
                          );
                        },
                        title: Text(
                          listing.offer,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            '${t('barter_want', lang)}: ${listing.want}\n${t('ubuntu_region', lang)}: $region',
                            style: const TextStyle(
                              color: Colors.white60,
                              height: 1.35,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'edit') {
                              _createOrEdit(listing: listing);
                              return;
                            }
                            if (value == 'delete') {
                              _confirmDelete(lang, listing);
                              return;
                            }
                          },
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: 'edit',
                              child: Text(t('edit', lang)),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: Text(t('delete', lang)),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF2D6A4F),
        foregroundColor: Colors.white,
        onPressed: () => _createOrEdit(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
