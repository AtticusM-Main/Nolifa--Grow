import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/livestock_health_record.dart';
import '../services/livestock_history_service.dart';
import '../services/livestock_symptom_service.dart';
import '../services/region_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'livestock_result_screen.dart';

class LivestockHealthCheckScreen extends ConsumerStatefulWidget {
  const LivestockHealthCheckScreen({super.key});

  @override
  ConsumerState<LivestockHealthCheckScreen> createState() => _LivestockHealthCheckScreenState();
}

class _LivestockHealthCheckScreenState extends ConsumerState<LivestockHealthCheckScreen> {
  final LivestockSymptomService _symptomService = LivestockSymptomService();
  final LivestockHistoryService _historyService = LivestockHistoryService();
  final RegionService _regionService = RegionService();
  final TextEditingController _notesController = TextEditingController();

  String _species = 'cattle';
  final Set<String> _symptoms = {};
  bool _saving = false;

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _assess(String lang) async {
    setState(() {
      _saving = true;
    });

    final result = _symptomService.assess(species: _species, symptoms: _symptoms);
    final regionKey = await _regionService.getRegion();

    final record = LivestockHealthRecord(
      id: const Uuid().v4(),
      species: _species,
      conditionKey: result['conditionKey'] as String,
      confidence: result['confidence'] as String,
      symptoms: _symptoms.toList(),
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      date: DateTime.now(),
      regionKey: regionKey,
    );

    await _historyService.saveRecord(record);

    if (!mounted) return;
    setState(() {
      _saving = false;
    });

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => LivestockResultScreen(record: record),
      ),
    );
  }

  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return FilterChip(
      selected: selected,
      onSelected: (_) => onTap(),
      label: Text(label),
      selectedColor: const Color(0xFF2D6A4F).withOpacity(0.35),
      checkmarkColor: Colors.white,
      labelStyle: TextStyle(color: selected ? Colors.white : Colors.white70),
      side: BorderSide(color: Colors.white.withOpacity(0.18)),
      backgroundColor: Colors.white10,
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final symptomDefs = <String, String>{
      'fever': t('ls_fever', lang),
      'weakness': t('ls_weakness', lang),
      'loss_of_appetite': t('ls_appetite', lang),
      'diarrhoea': t('ls_diarrhoea', lang),
      'weight_loss': t('ls_weight_loss', lang),
      'pale_gums': t('ls_pale_gums', lang),
      'coughing': t('ls_coughing', lang),
      'nasal_discharge': t('ls_discharge', lang),
      'skin_lumps': t('ls_lumps', lang),
      'ticks_visible': t('ls_ticks', lang),
      'limping': t('ls_limping', lang),
      'hoof_smell': t('ls_hoof_smell', lang),
      'hoof_swelling': t('ls_hoof_swelling', lang),
      'swollen_udder': t('ls_udder_swollen', lang),
      'abnormal_milk': t('ls_milk_abnormal', lang),
      'udder_pain': t('ls_udder_pain', lang),
      'swollen_belly': t('ls_bloat', lang),
      'breathing_difficulty': t('ls_breathing', lang),
      'restlessness': t('ls_restless', lang),
      'sudden_deaths': t('ls_sudden_deaths', lang),
      'nervous_signs': t('ls_nervous', lang),
    };

    final speciesOptions = <String, String>{
      'cattle': t('ls_cattle', lang),
      'goats': t('ls_goats', lang),
      'sheep': t('ls_sheep', lang),
      'poultry': t('ls_poultry', lang),
    };

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_check', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Text(
              t('livestock_check_intro', lang),
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    t('ls_species', lang),
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    value: _species,
                    dropdownColor: const Color(0xFF1B4332),
                    items: speciesOptions.entries
                        .map(
                          (e) => DropdownMenuItem(
                            value: e.key,
                            child: Text(
                              e.value,
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() {
                        _species = v;
                      });
                    },
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white10,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    t('ls_symptoms', lang),
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: symptomDefs.entries.map((e) {
                      final selected = _symptoms.contains(e.key);
                      return _chip(
                        label: e.value,
                        selected: selected,
                        onTap: () {
                          setState(() {
                            if (selected) {
                              _symptoms.remove(e.key);
                            } else {
                              _symptoms.add(e.key);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    t('livestock_notes', lang),
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _notesController,
                    maxLines: 3,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: t('livestock_notes_hint', lang),
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: Colors.white10,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.white.withOpacity(0.18)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton(
              onPressed: _saving ? null : () => _assess(lang),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2D6A4F),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: Text(_saving ? t('saving', lang) : t('livestock_assess', lang)),
            ),
          ],
        ),
      ),
    );
  }
}

