import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_condition_info.dart';
import '../models/livestock_health_record.dart';
import '../services/livestock_history_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'livestock_result_screen.dart';

class LivestockHistoryScreen extends ConsumerStatefulWidget {
  const LivestockHistoryScreen({super.key});

  @override
  ConsumerState<LivestockHistoryScreen> createState() => _LivestockHistoryScreenState();
}

class _LivestockHistoryScreenState extends ConsumerState<LivestockHistoryScreen> {
  final LivestockHistoryService _historyService = LivestockHistoryService();
  List<LivestockHealthRecord> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final h = await _historyService.getHistory();
    if (!mounted) return;
    setState(() {
      _history = h;
      _isLoading = false;
    });
  }

  Future<void> _clearHistory(String lang) async {
    final t = AppTranslations.get;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t('clear_history', lang)),
        content: Text(t('clear_history_confirm', lang)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(t('cancel', lang)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _historyService.clearHistory();
              if (!mounted) return;
              setState(() => _history = []);
            },
            child: Text(
              t('clear', lang),
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  Color _getSeverityColor(String colorName) {
    switch (colorName) {
      case 'green':
        return const Color(0xFF2D6A4F);
      case 'orange':
        return const Color(0xFFE07B39);
      case 'red':
        return const Color(0xFFD62828);
      default:
        return Colors.grey;
    }
  }

  String _formatDate(DateTime date, String lang) {
    final t = AppTranslations.get;
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return '${t('today', lang)} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    } else if (difference.inDays == 1) {
      return t('yesterday', lang);
    } else if (difference.inDays < 7) {
      return '${difference.inDays} ${t('days_ago', lang)}';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  IconData _speciesIcon(String species) {
    switch (species) {
      case 'cattle':
        return Icons.agriculture;
      case 'goats':
        return Icons.pets;
      case 'sheep':
        return Icons.grass;
      case 'poultry':
        return Icons.egg_alt;
      default:
        return Icons.pets;
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;
    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_history_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          if (_history.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _clearHistory(lang),
              tooltip: t('clear_history', lang),
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : _history.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.history, color: Colors.white24, size: 80),
                      const SizedBox(height: 16),
                      Text(
                        t('livestock_no_history', lang),
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        t('livestock_no_history_sub', lang),
                        style: const TextStyle(color: Colors.white38, fontSize: 14),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _history.length,
                  itemBuilder: (context, index) {
                    final record = _history[index];
                    final info = LivestockConditionDatabase.getInfo(record.conditionKey);
                    final severityColor = _getSeverityColor(info.severityColor);
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LivestockResultScreen(record: record),
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white10,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 42,
                                height: 42,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF2D6A4F),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(_speciesIcon(record.species), color: Colors.white),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      info.plainName,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        Container(
                                          width: 8,
                                          height: 8,
                                          decoration: BoxDecoration(
                                            color: severityColor,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Expanded(
                                          child: Text(
                                            info.severity,
                                            style: TextStyle(
                                              color: severityColor,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      _formatDate(record.date, lang),
                                      style: const TextStyle(
                                        color: Colors.white38,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.chevron_right, color: Colors.white38),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

