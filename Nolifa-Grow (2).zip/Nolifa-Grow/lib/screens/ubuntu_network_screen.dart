import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/region_service.dart';
import '../utils/kzn_regions.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'agronomist_request_screen.dart';
import 'barter_listings_screen.dart';
import 'plant_database_screen.dart';
import 'yield_predictor_screen.dart';

class UbuntuNetworkScreen extends ConsumerStatefulWidget {
  const UbuntuNetworkScreen({super.key});

  @override
  ConsumerState<UbuntuNetworkScreen> createState() =>
      _UbuntuNetworkScreenState();
}

class _UbuntuNetworkScreenState extends ConsumerState<UbuntuNetworkScreen> {
  final RegionService _regionService = RegionService();
  String? _regionKey;

  @override
  void initState() {
    super.initState();
    _loadRegion();
  }

  Future<void> _loadRegion() async {
    final region = await _regionService.getRegion();
    if (!mounted) return;
    setState(() {
      _regionKey = region;
    });
  }

  Future<void> _pickRegion(String lang) async {
    final t = AppTranslations.get;
    final chosen = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(t('region_skip', lang)),
              onTap: () => Navigator.pop(context, ''),
            ),
            ...KznRegions.keys.map(
              (key) => ListTile(
                title: Text(KznRegions.label(key, lang)),
                onTap: () => Navigator.pop(context, key),
              ),
            ),
          ],
        ),
      ),
    );

    if (chosen == null) return;
    if (chosen.isEmpty) {
      await _regionService.setRegion(null);
    } else {
      await _regionService.setRegion(chosen);
    }
    await _loadRegion();
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    final regionText = _regionKey == null
        ? t('region_skip', lang)
        : KznRegions.label(_regionKey!, lang);

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('ubuntu_title', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('ubuntu_subtitle', lang),
              style: const TextStyle(
                color: Colors.white70,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white24),
              ),
              child: Row(
                children: [
                  const Icon(Icons.place_outlined, color: Colors.white70),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '${t('ubuntu_region', lang)}: $regionText',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _pickRegion(lang),
                    child: Text(t('ubuntu_set_region', lang)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _ActionCard(
              icon: Icons.swap_horiz,
              title: t('ubuntu_barter', lang),
              subtitle: t('ubuntu_barter_sub', lang),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BarterListingsScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.eco_outlined,
              title: t('ubuntu_indigenous', lang),
              subtitle: t('ubuntu_indigenous_sub', lang),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PlantDatabaseScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.support_agent_outlined,
              title: t('ubuntu_agronomist', lang),
              subtitle: t('ubuntu_agronomist_sub', lang),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AgronomistRequestScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            _ActionCard(
              icon: Icons.insights_outlined,
              title: t('ubuntu_yield', lang),
              subtitle: t('ubuntu_yield_sub', lang),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const YieldPredictorScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white10,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFF2D6A4F),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: Colors.white),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white24),
            ],
          ),
        ),
      ),
    );
  }
}
