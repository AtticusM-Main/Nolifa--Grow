import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../utils/translations.dart';
import '../utils/language_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/disease_info.dart';
import '../services/history_service.dart';
import '../utils/kzn_regions.dart';

class DiseasePoint {
  final String regionKey;
  final LatLng location;
  final String disease;
  final String severity;
  final DateTime date;

  const DiseasePoint({
    required this.regionKey,
    required this.location,
    required this.disease,
    required this.severity,
    required this.date,
  });
}

class MapScreen extends ConsumerStatefulWidget {
  const MapScreen({super.key});

  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  final MapController _mapController = MapController();
  final HistoryService _historyService = HistoryService();

  late final List<DiseasePoint> _points;

  DiseasePoint? _selectedPoint;
  _HexCell? _selectedCell;
  String _selectedFilter = 'all';
  bool _hexView = true;
  int _timeWindowDays = 30;

  @override
  void initState() {
    super.initState();
    _points = [];
    _loadFromHistory();
  }

  Future<void> _loadFromHistory() async {
    final history = await _historyService.getHistory();
    final points = <DiseasePoint>[];
    for (final r in history) {
      final regionKey = r.regionKey ?? 'other';
      final center = _regionCenter(regionKey);
      if (center == null) continue;
      final jittered = _jitter(center, seed: r.id.hashCode);
      final info = DiseaseDatabase.getInfo(r.label);
      points.add(
        DiseasePoint(
          regionKey: regionKey,
          location: jittered,
          disease: r.label,
          severity: info.severityColor,
          date: r.date,
        ),
      );
    }

    if (!mounted) return;
    setState(() {
      _points
        ..clear()
        ..addAll(points);
      _selectedCell = null;
      _selectedPoint = null;
    });
  }

  LatLng? _regionCenter(String regionKey) {
    switch (regionKey) {
      case 'greater_durban':
        return const LatLng(-29.8587, 31.0218);
      case 'midlands':
        return const LatLng(-29.6167, 30.3833);
      case 'north_coast':
        return const LatLng(-29.4, 31.2);
      case 'south_coast':
        return const LatLng(-30.2, 30.8);
      case 'zululand':
        return const LatLng(-28.75, 31.88);
      case 'northern_kzn':
        return const LatLng(-27.8, 32.1);
      case 'other':
        return const LatLng(-29.0, 31.0);
      default:
        return null;
    }
  }

  LatLng _jitter(LatLng center, {required int seed}) {
    final r = math.Random(seed);
    final latJ = (r.nextDouble() - 0.5) * 0.12;
    final lonJ = (r.nextDouble() - 0.5) * 0.12;
    return LatLng(center.latitude + latJ, center.longitude + lonJ);
  }

  Color _getColor(String severity) {
    switch (severity) {
      case 'green':
        return const Color(0xFF2D6A4F);
      case 'orange':
        return const Color(0xFFE07B39);
      case 'red':
        return const Color(0xFFD62828);
      default:
        return Colors.grey;
    }
  }

  List<DiseasePoint> get _filteredPoints {
    final now = DateTime.now();
    final windowed = _timeWindowDays <= 0
        ? _points
        : _points.where((p) => now.difference(p.date).inDays <= _timeWindowDays);

    if (_selectedFilter == 'all') return windowed.toList();
    return windowed.where((p) => p.severity == _selectedFilter).toList();
  }

  int _countBySeverity(String severity) {
    return _filteredPoints.where((p) => p.severity == severity).length;
  }

  String _formatDate(DateTime date) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(date.day)}/${two(date.month)}/${date.year}';
  }

  double _latStepForZoom(double zoom) {
    final z = zoom.clamp(6.0, 16.0);
    final scale = 1 << (z.round() - 7).clamp(0, 9);
    return (0.45 / scale).clamp(0.01, 0.45);
  }

  double _lonStepForZoom(double zoom, double lat) {
    final latStep = _latStepForZoom(zoom);
    final cosLat = math.cos(lat.abs() * 0.017453292519943295);
    final base = latStep / (cosLat == 0 ? 1 : cosLat);
    return base.clamp(latStep * 0.8, latStep * 1.6);
  }

  List<_HexCell> _buildHexCells(double zoom) {
    if (_filteredPoints.isEmpty) return const [];

    final avgLat = _filteredPoints
            .map((p) => p.location.latitude)
            .reduce((a, b) => a + b) /
        _filteredPoints.length;

    final latStep = _latStepForZoom(zoom);
    final lonStep = _lonStepForZoom(zoom, avgLat);

    final Map<String, List<DiseasePoint>> grouped = {};
    for (final p in _filteredPoints) {
      final row = (p.location.latitude / latStep).round();
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      final col = ((p.location.longitude + offset) / lonStep).round();
      final key = '$row:$col';
      grouped.putIfAbsent(key, () => []).add(p);
    }

    final cells = <_HexCell>[];
    grouped.forEach((key, points) {
      final parts = key.split(':');
      final row = int.parse(parts[0]);
      final col = int.parse(parts[1]);
      final offset = row.isOdd ? lonStep / 2 : 0.0;

      final center = LatLng(row * latStep, (col * lonStep) - offset);
      final severity = _aggregateSeverity(points);
      final outbreaks = _topOutbreaks(points);

      cells.add(
        _HexCell(
          center: center,
          points: points,
          severity: severity,
          topOutbreaks: outbreaks,
        ),
      );
    });

    cells.sort((a, b) => b.points.length.compareTo(a.points.length));
    return cells;
  }

  List<Polygon> _buildHexGridPolygons(double zoom) {
    final center = _mapController.camera.center;
    final latStep = _latStepForZoom(zoom);
    final lonStep = _lonStepForZoom(zoom, center.latitude);

    final grouped = <String, List<DiseasePoint>>{};
    for (final p in _filteredPoints) {
      final row = (p.location.latitude / latStep).round();
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      final col = ((p.location.longitude + offset) / lonStep).round();
      final key = '$row:$col';
      grouped.putIfAbsent(key, () => []).add(p);
    }

    final row0 = (center.latitude / latStep).round();
    final offset0 = row0.isOdd ? lonStep / 2 : 0.0;
    final col0 = ((center.longitude + offset0) / lonStep).round();

    final z = zoom.clamp(6.0, 16.0);
    final half = z <= 7.5
        ? 8
        : z <= 10.5
            ? 10
            : 12;

    final polygons = <Polygon>[];
    for (var row = row0 - half; row <= row0 + half; row++) {
      final offset = row.isOdd ? lonStep / 2 : 0.0;
      for (var col = col0 - half; col <= col0 + half; col++) {
        final key = '$row:$col';
        final points = grouped[key] ?? const <DiseasePoint>[];
        final severity = points.isEmpty ? 'none' : _aggregateSeverity(points);
        final color = points.isEmpty
            ? Colors.white.withOpacity(0.03)
            : _getColor(severity).withOpacity(
                (0.10 + (points.length.clamp(1, 6) * 0.03)).clamp(0.10, 0.30),
              );

        final border = points.isEmpty
            ? Colors.white.withOpacity(0.08)
            : _getColor(severity).withOpacity(0.40);

        final centerLat = row * latStep;
        final centerLon = (col * lonStep) - offset;
        final centerPoint = LatLng(centerLat, centerLon);
        final hexPoints = _hexPolygonPoints(
          center: centerPoint,
          latStep: latStep,
          lonStep: lonStep,
        );

        polygons.add(
          Polygon(
            points: hexPoints,
            color: color,
            borderColor: border,
            borderStrokeWidth: points.isEmpty ? 0.8 : 1.4,
          ),
        );
      }
    }

    return polygons;
  }

  List<LatLng> _hexPolygonPoints({
    required LatLng center,
    required double latStep,
    required double lonStep,
  }) {
    final rLat = (latStep / 2) * 0.92;
    final rLon = (lonStep / 2) * 0.92;
    final points = <LatLng>[];

    for (var i = 0; i < 6; i++) {
      final angle = (60.0 * i - 30.0) * 0.017453292519943295;
      final lat = center.latitude + (rLat * math.sin(angle));
      final lon = center.longitude + (rLon * math.cos(angle));
      points.add(LatLng(lat, lon));
    }
    return points;
  }

  String _aggregateSeverity(List<DiseasePoint> points) {
    if (points.any((p) => p.severity == 'red')) return 'red';
    if (points.any((p) => p.severity == 'orange')) return 'orange';
    return 'green';
  }

  List<_OutbreakStat> _topOutbreaks(List<DiseasePoint> points) {
    final counts = <String, int>{};
    for (final p in points) {
      counts[p.disease] = (counts[p.disease] ?? 0) + 1;
    }
    final list = counts.entries
        .map((e) => _OutbreakStat(disease: e.key, count: e.value))
        .toList();
    list.sort((a, b) => b.count.compareTo(a.count));
    return list.take(3).toList();
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;
    final zoom = (_mapController.camera.zoom == 0)
        ? 7.0
        : _mapController.camera.zoom;
    final cells = _hexView ? _buildHexCells(zoom) : const <_HexCell>[];
    final hexGridPolygons =
        _hexView ? _buildHexGridPolygons(zoom) : const <Polygon>[];

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('map_title', lang),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.white,
              ),
            ),
            Text(
              t('map_subtitle', lang),
              style: const TextStyle(
                fontSize: 11,
                color: Colors.white54,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: t('map_refresh', lang),
            onPressed: _loadFromHistory,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: t('map_hex_toggle', lang),
            onPressed: () {
              setState(() {
                _hexView = !_hexView;
                _selectedCell = null;
                _selectedPoint = null;
              });
            },
            icon: Icon(_hexView ? Icons.hexagon : Icons.place_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          // Stats bar
          Container(
            color: const Color(0xFF1B4332),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                _buildStatChip(
                  t('filter_all', lang),
                  _filteredPoints.length,
                  Colors.white24,
                  'all',
                ),
                const SizedBox(width: 8),
                _buildStatChip(t('map_healthy', lang), _countBySeverity('green'), const Color(0xFF2D6A4F), 'green'),
                const SizedBox(width: 8),
                _buildStatChip(t('map_moderate', lang), _countBySeverity('orange'), const Color(0xFFE07B39), 'orange'),
                const SizedBox(width: 8),
                _buildStatChip(t('map_urgent', lang), _countBySeverity('red'), const Color(0xFFD62828), 'red'),
              ],
            ),
          ),
          Container(
            color: const Color(0xFF1B4332),
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(
              children: [
                _buildTimeChip(t('map_time_24h', lang), 1),
                const SizedBox(width: 8),
                _buildTimeChip(t('map_time_7d', lang), 7),
                const SizedBox(width: 8),
                _buildTimeChip(t('map_time_30d', lang), 30),
                const SizedBox(width: 8),
                _buildTimeChip(t('map_time_all', lang), 0),
              ],
            ),
          ),

          // Map
          Expanded(
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: const LatLng(-29.0, 31.0),
                    initialZoom: 7.0,
                    interactionOptions: const InteractionOptions(
                      flags: InteractiveFlag.all,
                    ),
                    minZoom: 6.0,
                    maxZoom: 16.0,
                    onPositionChanged: (_, __) => setState(() {}),
                    onTap: (_, __) => setState(() {
                      _selectedPoint = null;
                      _selectedCell = null;
                    }),
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'com.nolifagrow.nolifa_grow',
                    ),
                    if (_hexView)
                      PolygonLayer(
                        polygons: hexGridPolygons,
                      ),
                    MarkerLayer(
                      markers: _hexView
                          ? cells
                              .map(
                                (cell) => Marker(
                                  point: cell.center,
                                  width: _markerSizeForZoom(zoom),
                                  height: _markerSizeForZoom(zoom),
                                  child: GestureDetector(
                                    onTap: () {
                                      final targetZoom =
                                          (_mapController.camera.zoom + 1.5)
                                              .clamp(7.0, 15.0);
                                      _mapController.move(
                                        cell.center,
                                        targetZoom,
                                      );
                                      setState(() {
                                        _selectedCell = cell;
                                        _selectedPoint = null;
                                      });
                                    },
                                    child: _HexMarker(
                                      size: _markerSizeForZoom(zoom),
                                      color: _getColor(cell.severity),
                                      count: cell.points.length,
                                    ),
                                  ),
                                ),
                              )
                              .toList()
                          : _filteredPoints
                              .map((point) => Marker(
                                    point: point.location,
                                    width: 28,
                                    height: 28,
                                    child: GestureDetector(
                                      onTap: () {
                                        final targetZoom =
                                            (_mapController.camera.zoom + 2.0)
                                                .clamp(8.0, 16.0);
                                        _mapController.move(
                                          point.location,
                                          targetZoom,
                                        );
                                        setState(() {
                                          _selectedPoint = point;
                                          _selectedCell = null;
                                        });
                                      },
                                      child: Container(
                                        width: 28,
                                        height: 28,
                                        decoration: BoxDecoration(
                                          color: _getColor(point.severity),
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: _getColor(point.severity)
                                                  .withOpacity(0.4),
                                              blurRadius: 8,
                                              spreadRadius: 2,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ))
                              .toList(),
                    ),
                  ],
                ),

                if (_filteredPoints.isEmpty)
                  Positioned(
                    left: 16,
                    right: 16,
                    bottom: 16,
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            t('map_empty_title', lang),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            t('map_empty_sub', lang),
                            style: const TextStyle(
                              color: Colors.white70,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                if (_hexView)
                  Positioned(
                    right: 16,
                    bottom: 16,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            t('map_legend', lang),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(height: 8),
                          _LegendRow(
                            color: Colors.white.withOpacity(0.10),
                            label: t('map_density_low', lang),
                          ),
                          const SizedBox(height: 6),
                          _LegendRow(
                            color: _getColor('orange').withOpacity(0.18),
                            label: t('map_density_med', lang),
                          ),
                          const SizedBox(height: 6),
                          _LegendRow(
                            color: _getColor('red').withOpacity(0.28),
                            label: t('map_density_high', lang),
                          ),
                        ],
                      ),
                    ),
                  ),

                // Selected point info card
                if (_selectedPoint != null)
                  Positioned(
                    top: 16,
                    left: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: _getColor(_selectedPoint!.severity),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedPoint!.disease,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    color: Color(0xFF1a1a1a),
                                  ),
                                ),
                                Text(
                                  '${KznRegions.label(_selectedPoint!.regionKey, lang)} — ${_formatDate(_selectedPoint!.date)}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.black54,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                _OutbreakDetail(
                                  disease: _selectedPoint!.disease,
                                  lang: lang,
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () => setState(() => _selectedPoint = null),
                            child: const Icon(
                              Icons.close,
                              size: 18,
                              color: Colors.black38,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (_selectedCell != null)
                  Positioned(
                    top: 16,
                    left: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: _getColor(_selectedCell!.severity),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  t('map_outbreak_details', lang),
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    color: Color(0xFF1a1a1a),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () => setState(() => _selectedCell = null),
                                child: const Icon(
                                  Icons.close,
                                  size: 18,
                                  color: Colors.black38,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${t('map_cases', lang)}: ${_selectedCell!.points.length}',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            t('map_top_outbreaks', lang),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: Color(0xFF1a1a1a),
                            ),
                          ),
                          const SizedBox(height: 6),
                          ..._selectedCell!.topOutbreaks.map((o) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 6),
                              child: Text(
                                '• ${o.disease} (${o.count})',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.black87,
                                ),
                              ),
                            );
                          }),
                          if (_selectedCell!.topOutbreaks.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            _OutbreakDetail(
                              disease: _selectedCell!.topOutbreaks.first.disease,
                              lang: lang,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  double _markerSizeForZoom(double zoom) {
    final z = zoom.clamp(6.0, 16.0);
    return (26 + (z - 7) * 4).clamp(22, 56).toDouble();
  }

  Widget _buildTimeChip(String label, int days) {
    final isSelected = _timeWindowDays == days;
    return GestureDetector(
      onTap: () => setState(() {
        _timeWindowDays = days;
        _selectedPoint = null;
        _selectedCell = null;
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white24 : Colors.white10,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? Colors.white60 : Colors.white24,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildStatChip(String label, int count, Color color, String filter) {
    final isSelected = _selectedFilter == filter;
    return GestureDetector(
      onTap: () => setState(() => _selectedFilter = filter),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? color : color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? Colors.white : color,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '$count',
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegendRow extends StatelessWidget {
  final Color color;
  final String label;

  const _LegendRow({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.hexagon,
          size: 14,
          color: color,
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}

class _HexCell {
  final LatLng center;
  final List<DiseasePoint> points;
  final String severity;
  final List<_OutbreakStat> topOutbreaks;

  const _HexCell({
    required this.center,
    required this.points,
    required this.severity,
    required this.topOutbreaks,
  });
}

class _OutbreakStat {
  final String disease;
  final int count;

  const _OutbreakStat({required this.disease, required this.count});
}

class _HexMarker extends StatelessWidget {
  final double size;
  final Color color;
  final int count;

  const _HexMarker({
    required this.size,
    required this.color,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _HexPainter(color: color),
      child: Center(
        child: Text(
          '$count',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
      size: Size(size, size),
    );
  }
}

class _HexPainter extends CustomPainter {
  final Color color;

  const _HexPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.9)
      ..style = PaintingStyle.fill;
    final border = Paint()
      ..color = Colors.white.withOpacity(0.95)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final r = size.width / 2;
    final cx = r;
    final cy = r;

    final path = Path();
    for (var i = 0; i < 6; i++) {
      final angle = (60.0 * i - 30.0) * 0.017453292519943295;
      final x = cx + r * 0.92 * math.cos(angle);
      final y = cy + r * 0.92 * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    canvas.drawPath(path, paint);
    canvas.drawPath(path, border);
  }

  @override
  bool shouldRepaint(covariant _HexPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

class _OutbreakDetail extends StatelessWidget {
  final String disease;
  final String lang;

  const _OutbreakDetail({required this.disease, required this.lang});

  @override
  Widget build(BuildContext context) {
    final t = AppTranslations.get;
    final info = DiseaseDatabase.getInfo(disease);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          t('map_remedy', lang),
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 13,
            color: Color(0xFF1a1a1a),
          ),
        ),
        const SizedBox(height: 6),
        ...info.treatment.take(3).map(
              (step) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '• $step',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black87,
                    height: 1.35,
                  ),
                ),
              ),
            ),
        if ((info.homRemedy).trim().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(
            '${t('home_remedy', lang)}: ${info.homRemedy}',
            style: const TextStyle(
              fontSize: 12,
              color: Colors.black54,
              height: 1.35,
            ),
          ),
        ],
      ],
    );
  }
}
