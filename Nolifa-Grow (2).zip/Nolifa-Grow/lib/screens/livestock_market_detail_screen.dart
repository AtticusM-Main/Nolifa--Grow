import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_market_listing.dart';
import '../services/livestock_market_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'chat_screen.dart';
import 'livestock_market_form_screen.dart';

class LivestockMarketDetailScreen extends ConsumerStatefulWidget {
  final String listingId;

  const LivestockMarketDetailScreen({super.key, required this.listingId});

  @override
  ConsumerState<LivestockMarketDetailScreen> createState() => _LivestockMarketDetailScreenState();
}

class _LivestockMarketDetailScreenState extends ConsumerState<LivestockMarketDetailScreen> {
  final LivestockMarketService _service = LivestockMarketService();
  LivestockMarketListing? _listing;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await _service.getListings();
    final l = all.where((e) => e.id == widget.listingId).toList();
    if (!mounted) return;
    setState(() {
      _listing = l.isEmpty ? null : l.first;
      _loading = false;
    });
  }

  Future<void> _delete(String lang) async {
    final t = AppTranslations.get;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t('delete', lang)),
        content: Text(t('livestock_market_delete_confirm', lang)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(t('cancel', lang)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(t('delete', lang), style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _service.deleteListing(widget.listingId);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  String _typeLabel(String type, String lang) {
    final t = AppTranslations.get;
    switch (type) {
      case 'need':
        return t('livestock_market_need', lang);
      case 'swap':
        return t('livestock_market_swap', lang);
      default:
        return t('livestock_market_offer', lang);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_market', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          if (!_loading && _listing != null)
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              tooltip: t('edit', lang),
              onPressed: () async {
                final changed = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LivestockMarketFormScreen(existing: _listing),
                  ),
                );
                if (changed == true) {
                  _load();
                }
              },
            ),
          if (!_loading && _listing != null)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: t('delete', lang),
              onPressed: () => _delete(lang),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : _listing == null
              ? Center(
                  child: Text(
                    t('livestock_market_not_found', lang),
                    style: const TextStyle(color: Colors.white54),
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white10,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _listing!.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                _pill(_typeLabel(_listing!.listingType, lang)),
                                const SizedBox(width: 8),
                                _pill(t('ls_${_listing!.species}', lang)),
                                const SizedBox(width: 8),
                                _pill(t(_listing!.regionKey, lang)),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _listing!.description.isEmpty ? t('livestock_market_no_description', lang) : _listing!.description,
                              style: const TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.white12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                t('livestock_market_contact', lang),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                t('livestock_market_contact_sub', lang),
                                style: const TextStyle(color: Colors.white70, fontSize: 13),
                              ),
                              const Spacer(),
                              ElevatedButton(
                                onPressed: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ChatScreen(
                                      threadId: 'livestock_${_listing!.id}',
                                      title: t('livestock_chat_title', lang),
                                    ),
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF2D6A4F),
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: Text(t('livestock_market_message', lang)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _pill(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white12,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white12),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }
}

