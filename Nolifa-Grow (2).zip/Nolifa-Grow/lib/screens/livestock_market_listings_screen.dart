import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/livestock_market_listing.dart';
import '../services/livestock_market_service.dart';
import '../utils/language_provider.dart';
import '../utils/translations.dart';
import 'livestock_market_detail_screen.dart';
import 'livestock_market_form_screen.dart';

class LivestockMarketListingsScreen extends ConsumerStatefulWidget {
  const LivestockMarketListingsScreen({super.key});

  @override
  ConsumerState<LivestockMarketListingsScreen> createState() => _LivestockMarketListingsScreenState();
}

class _LivestockMarketListingsScreenState extends ConsumerState<LivestockMarketListingsScreen> {
  final LivestockMarketService _service = LivestockMarketService();
  List<LivestockMarketListing> _listings = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await _service.getListings();
    if (!mounted) return;
    setState(() {
      _listings = l;
      _loading = false;
    });
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'need':
        return Icons.shopping_cart_outlined;
      case 'swap':
        return Icons.swap_horiz;
      default:
        return Icons.sell_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(languageProvider);
    final t = AppTranslations.get;

    return Scaffold(
      backgroundColor: const Color(0xFF1B4332),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B4332),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          t('livestock_market', lang),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: _load,
            tooltip: t('map_refresh', lang),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final changed = await Navigator.push<bool>(
            context,
            MaterialPageRoute(builder: (context) => const LivestockMarketFormScreen()),
          );
          if (changed == true) {
            _load();
          }
        },
        backgroundColor: const Color(0xFF2D6A4F),
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : _listings.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.swap_horiz, color: Colors.white24, size: 80),
                      const SizedBox(height: 14),
                      Text(
                        t('livestock_market_empty', lang),
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        t('livestock_market_empty_sub', lang),
                        style: const TextStyle(color: Colors.white38, fontSize: 14),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _listings.length,
                  itemBuilder: (context, i) {
                    final l = _listings[i];
                    return GestureDetector(
                      onTap: () async {
                        final changed = await Navigator.push<bool>(
                          context,
                          MaterialPageRoute(builder: (context) => LivestockMarketDetailScreen(listingId: l.id)),
                        );
                        if (changed == true) {
                          _load();
                        }
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white10,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: const Color(0xFF2D6A4F),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(_typeIcon(l.listingType), color: Colors.white),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    l.title,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    '${t('ls_species', lang)}: ${t('ls_${l.species}', lang)} • ${t(l.regionKey, lang)}',
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right, color: Colors.white38),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

