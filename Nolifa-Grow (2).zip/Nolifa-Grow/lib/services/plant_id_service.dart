import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;

class PlantIdService {
  static const String _apiKey =
      String.fromEnvironment('PLANT_ID_API_KEY', defaultValue: '');
  static const String _baseUrl = 'https://plant.id/api/v3';

  Future<Map<String, dynamic>?> diagnose(File imageFile) async {
    if (_apiKey.trim().isEmpty) {
      return null;
    }
    try {
      final imageBytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(imageBytes);

      final response = await http.post(
        Uri.parse('$_baseUrl/health_assessment'),
        headers: {
          'Api-Key': _apiKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'images': [base64Image],
          'health': 'all',
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return _parseResponse(data);
      } else {
        return null;
      }
    } catch (e) {
      return null;
    }
  }

  Map<String, dynamic>? _parseResponse(Map<String, dynamic> data) {
    try {
      final result = data['result'];
      final isHealthy = result['is_healthy']['binary'];
      final healthProbability = result['is_healthy']['probability'];

      if (isHealthy) {
        return {
          'label': 'Healthy',
          'confidence': (healthProbability * 100).toStringAsFixed(1),
          'isHealthy': true,
          'diseases': [],
        };
      }

      final diseases = result['disease']['suggestions'] as List;
      if (diseases.isEmpty) {
        return {
          'label': 'Unknown',
          'confidence': '0',
          'isHealthy': false,
          'diseases': [],
        };
      }

      final topDisease = diseases[0];
      final diseaseName = topDisease['name'];
      final probability = topDisease['probability'];

      return {
        'label': diseaseName,
        'confidence': (probability * 100).toStringAsFixed(1),
        'isHealthy': false,
        'diseases': diseases
            .take(3)
            .map((d) => {
                  'name': d['name'],
                  'confidence':
                      (d['probability'] * 100).toStringAsFixed(1),
                })
            .toList(),
      };
    } catch (e) {
      return null;
    }
  }
}
