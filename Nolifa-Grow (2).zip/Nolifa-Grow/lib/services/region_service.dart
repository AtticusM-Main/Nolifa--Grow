import 'package:shared_preferences/shared_preferences.dart';

class RegionService {
  static const _key = 'region_code';

  Future<String?> getRegion() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_key);
  }

  Future<void> setRegion(String? regionKey) async {
    final prefs = await SharedPreferences.getInstance();
    if (regionKey == null) {
      await prefs.remove(_key);
      return;
    }
    await prefs.setString(_key, regionKey);
  }
}

