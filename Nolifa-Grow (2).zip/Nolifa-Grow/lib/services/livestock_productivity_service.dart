import '../models/livestock_productivity_prediction.dart';

class LivestockProductivityService {
  LivestockProductivityPrediction predict({
    required String species,
    required int herdSize,
    required double avgWeightKg,
    required String feedQuality,
    required int humidityPct,
    required String diseasePressure,
    required double pricePerKg,
  }) {
    final baseGainPerHead = switch (species) {
      'cattle' => 0.75,
      'goats' => 0.18,
      'sheep' => 0.20,
      'poultry' => 0.05,
      _ => 0.40,
    };

    final feedMult = switch (feedQuality) {
      'low' => 0.65,
      'medium' => 0.85,
      'high' => 1.00,
      _ => 0.85,
    };

    final humidityMult = humidityPct >= 85
        ? 0.88
        : humidityPct >= 75
            ? 0.93
            : 1.0;

    final diseaseMult = switch (diseasePressure) {
      'low' => 1.0,
      'medium' => 0.9,
      'high' => 0.78,
      _ => 0.9,
    };

    final gainPerHeadPerDay =
        (baseGainPerHead * feedMult * humidityMult * diseaseMult).clamp(0.01, 2.0);

    final targetGain = switch (species) {
      'cattle' => 80.0,
      'goats' => 12.0,
      'sheep' => 14.0,
      'poultry' => 1.5,
      _ => 25.0,
    };

    final days = (targetGain / gainPerHeadPerDay).clamp(14.0, 365.0).round();
    final expectedGainKgPerHead = (gainPerHeadPerDay * days).clamp(0.1, targetGain);
    final totalGain = expectedGainKgPerHead * herdSize;
    final revenue = totalGain * pricePerKg;

    final risk = _risk(humidityPct: humidityPct, feedQuality: feedQuality, diseasePressure: diseasePressure);

    final recs = <String>[
      if (feedQuality == 'low') 'Improve feed energy/protein using locally available supplements.',
      if (humidityPct >= 80) 'Increase ventilation/shade and keep bedding dry to reduce stress and infection.',
      if (diseasePressure != 'low') 'Prioritize parasite/tick control and isolate sick animals early.',
      'Track weekly weight changes (or body condition score) to adjust feeding early.',
    ];

    final headline = 'Expected gain: ${totalGain.toStringAsFixed(1)} kg across the herd';

    return LivestockProductivityPrediction(
      headline: headline,
      riskLevel: risk.$1,
      riskColor: risk.$2,
      daysToMarket: days,
      expectedGainKg: totalGain,
      expectedRevenue: revenue,
      recommendations: recs,
    );
  }

  (String, String) _risk({
    required int humidityPct,
    required String feedQuality,
    required String diseasePressure,
  }) {
    var score = 0;
    if (humidityPct >= 85) score += 2;
    if (humidityPct >= 75) score += 1;
    if (feedQuality == 'low') score += 2;
    if (feedQuality == 'medium') score += 1;
    if (diseasePressure == 'high') score += 3;
    if (diseasePressure == 'medium') score += 2;

    if (score >= 6) return ('High risk', 'red');
    if (score >= 3) return ('Medium risk', 'orange');
    return ('Low risk', 'green');
  }
}

