import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/agronomist_request.dart';

class AgronomistService {
  static const _key = 'agronomist_requests_v1';

  Future<List<AgronomistRequest>> getRequests() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const [];
    final requests = raw
        .map((s) {
          try {
            return AgronomistRequest.fromJson(
              jsonDecode(s) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<AgronomistRequest>()
        .toList();

    requests.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return requests;
  }

  Future<void> submitRequest(AgronomistRequest request) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    raw.insert(0, jsonEncode(request.toJson()));
    await prefs.setStringList(_key, raw);
  }
}

