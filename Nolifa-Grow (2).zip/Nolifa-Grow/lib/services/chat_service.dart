import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import '../models/chat_message.dart';

class ChatService {
  static const _prefix = 'chat_thread_v1_';

  Future<List<ChatMessage>> getThread(String threadId) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('$_prefix$threadId') ?? const [];
    final msgs = raw
        .map((s) {
          try {
            return ChatMessage.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ChatMessage>()
        .toList();

    msgs.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return msgs;
  }

  Future<void> sendMessage({
    required String threadId,
    required String text,
    required bool fromMe,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final key = '$_prefix$threadId';
    final raw = prefs.getStringList(key) ?? <String>[];

    final msg = ChatMessage(
      id: const Uuid().v4(),
      threadId: threadId,
      text: text,
      fromMe: fromMe,
      createdAt: DateTime.now(),
    );

    raw.add(jsonEncode(msg.toJson()));
    await prefs.setStringList(key, raw);
  }
}

