import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_user.dart';

class AuthService {
  static const _usersKey = 'users_v1';
  static const _sessionKey = 'session_user_id_v1';

  Future<AppUser?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString(_sessionKey);
    if (id == null || id.isEmpty) return null;
    final users = await _loadUsers(prefs);
    return users.where((u) => u.id == id).cast<AppUser?>().firstWhere(
          (u) => u != null,
          orElse: () => null,
        );
  }

  Future<AppUser> register({
    required String name,
    required String phone,
    required String pin,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final users = await _loadUsers(prefs);

    final normalizedPhone = _normalizePhone(phone);
    final exists = users.any((u) => _normalizePhone(u.phone) == normalizedPhone);
    if (exists) {
      throw StateError('Phone already registered');
    }

    final user = AppUser(
      id: normalizedPhone,
      name: name.trim(),
      phone: phone.trim(),
      pin: pin.trim(),
    );
    users.add(user);
    await _saveUsers(prefs, users);
    await prefs.setString(_sessionKey, user.id);
    return user;
  }

  Future<AppUser> login({
    required String phone,
    required String pin,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final users = await _loadUsers(prefs);
    final normalizedPhone = _normalizePhone(phone);

    final user = users.firstWhere(
      (u) => _normalizePhone(u.phone) == normalizedPhone,
      orElse: () => throw StateError('User not found'),
    );

    if (user.pin != pin.trim()) {
      throw StateError('Invalid PIN');
    }

    await prefs.setString(_sessionKey, user.id);
    return user;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_sessionKey);
  }

  String _normalizePhone(String phone) {
    final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
    return digits;
  }

  Future<List<AppUser>> _loadUsers(SharedPreferences prefs) async {
    final raw = prefs.getStringList(_usersKey) ?? const <String>[];
    final users = raw
        .map((s) {
          try {
            return AppUser.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<AppUser>()
        .toList();
    return users;
  }

  Future<void> _saveUsers(
    SharedPreferences prefs,
    List<AppUser> users,
  ) async {
    final raw = users.map((u) => jsonEncode(u.toJson())).toList();
    await prefs.setStringList(_usersKey, raw);
  }
}

