import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/plant_species.dart';

class PlantDatabaseService {
  Future<List<PlantSpecies>> loadKznPlants() async {
    final raw = await rootBundle.loadString('assets/data/kzn_plants.json');
    final decoded = jsonDecode(raw);
    if (decoded is! List) return const [];
    final plants = decoded
        .whereType<Map>()
        .map((e) => PlantSpecies.fromJson(e.cast<String, dynamic>()))
        .toList();

    plants.sort((a, b) => a.commonNameEn.compareTo(b.commonNameEn));
    return plants;
  }
}

