import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/livestock_health_record.dart';

class LivestockHistoryService {
  static const String _key = 'livestock_health_history_v1';

  Future<void> saveRecord(LivestockHealthRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> history = prefs.getStringList(_key) ?? <String>[];
    history.insert(0, jsonEncode(record.toMap()));
    if (history.length > 80) {
      history.removeLast();
    }
    await prefs.setStringList(_key, history);
  }

  Future<List<LivestockHealthRecord>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> history = prefs.getStringList(_key) ?? const [];

    return history
        .map((item) {
          try {
            return LivestockHealthRecord.fromMap(
              jsonDecode(item) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<LivestockHealthRecord>()
        .toList();
  }

  Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

