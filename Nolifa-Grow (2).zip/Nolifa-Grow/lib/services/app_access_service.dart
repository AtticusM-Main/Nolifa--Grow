import 'package:shared_preferences/shared_preferences.dart';

enum AppAccess {
  plantsOnly,
  livestockOnly,
  both,
}

class AppAccessService {
  static const _prefix = 'app_access_v1_';

  Future<AppAccess?> getAccess(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('$_prefix$userId');
    return switch (raw) {
      'plants' => AppAccess.plantsOnly,
      'livestock' => AppAccess.livestockOnly,
      'both' => AppAccess.both,
      _ => null,
    };
  }

  Future<void> setAccess(String userId, AppAccess access) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = switch (access) {
      AppAccess.plantsOnly => 'plants',
      AppAccess.livestockOnly => 'livestock',
      AppAccess.both => 'both',
    };
    await prefs.setString('$_prefix$userId', raw);
  }
}

