class LivestockSymptomService {
  Map<String, dynamic> assess({
    required String species,
    required Set<String> symptoms,
  }) {
    final scores = <String, int>{
      'healthy': 1,
      'worms': 0,
      'mastitis': 0,
      'foot_rot': 0,
      'tick_borne': 0,
      'bloat': 0,
      'newcastle': 0,
      'lumpy_skin': 0,
    };

    void bump(String key, int v) {
      scores[key] = (scores[key] ?? 0) + v;
    }

    if (symptoms.isEmpty) {
      return {'conditionKey': 'healthy', 'confidence': '68'};
    }

    if (symptoms.contains('diarrhoea')) {
      bump('worms', 3);
      bump('newcastle', species == 'poultry' ? 2 : 0);
    }
    if (symptoms.contains('weight_loss')) bump('worms', 3);
    if (symptoms.contains('pale_gums')) bump('worms', 2);

    if (symptoms.contains('swollen_udder')) bump('mastitis', 4);
    if (symptoms.contains('abnormal_milk')) bump('mastitis', 4);
    if (symptoms.contains('udder_pain')) bump('mastitis', 2);

    if (symptoms.contains('limping')) bump('foot_rot', 3);
    if (symptoms.contains('hoof_smell')) bump('foot_rot', 3);
    if (symptoms.contains('hoof_swelling')) bump('foot_rot', 2);

    if (symptoms.contains('ticks_visible')) bump('tick_borne', 3);
    if (symptoms.contains('fever')) {
      bump('tick_borne', 2);
      bump('lumpy_skin', species == 'cattle' ? 2 : 0);
      bump('mastitis', 1);
      bump('newcastle', species == 'poultry' ? 2 : 0);
    }
    if (symptoms.contains('weakness')) bump('tick_borne', 2);
    if (symptoms.contains('loss_of_appetite')) {
      bump('tick_borne', 1);
      bump('lumpy_skin', species == 'cattle' ? 1 : 0);
    }

    if (symptoms.contains('swollen_belly')) bump('bloat', 4);
    if (symptoms.contains('breathing_difficulty')) bump('bloat', 2);
    if (symptoms.contains('restlessness')) bump('bloat', 2);

    if (symptoms.contains('coughing')) bump('newcastle', species == 'poultry' ? 2 : 1);
    if (symptoms.contains('nasal_discharge')) bump('newcastle', species == 'poultry' ? 2 : 1);
    if (symptoms.contains('sudden_deaths')) bump('newcastle', species == 'poultry' ? 5 : 0);
    if (symptoms.contains('nervous_signs')) bump('newcastle', species == 'poultry' ? 4 : 0);

    if (symptoms.contains('skin_lumps')) bump('lumpy_skin', species == 'cattle' ? 5 : 0);

    var topKey = 'healthy';
    var topScore = -1;
    scores.forEach((k, v) {
      if (v > topScore) {
        topScore = v;
        topKey = k;
      }
    });

    final total = scores.values.fold<int>(0, (a, b) => a + b);
    final raw = total == 0 ? 0.0 : (topScore / total);
    final conf = (55 + (raw * 40)).clamp(55, 92).round();

    return {
      'conditionKey': topKey,
      'confidence': conf.toString(),
    };
  }
}

