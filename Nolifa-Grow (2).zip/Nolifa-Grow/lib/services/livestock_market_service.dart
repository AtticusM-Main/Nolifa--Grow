import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/livestock_market_listing.dart';

class LivestockMarketService {
  static const _key = 'livestock_market_listings_v1';

  Future<List<LivestockMarketListing>> getListings() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const [];
    final listings = raw
        .map((s) {
          try {
            return LivestockMarketListing.fromJson(
              jsonDecode(s) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<LivestockMarketListing>()
        .toList();

    listings.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return listings;
  }

  Future<void> upsertListing(LivestockMarketListing listing) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    final items = raw
        .map((s) {
          try {
            return LivestockMarketListing.fromJson(
              jsonDecode(s) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<LivestockMarketListing>()
        .toList();

    final idx = items.indexWhere((e) => e.id == listing.id);
    if (idx >= 0) {
      items[idx] = listing;
    } else {
      items.insert(0, listing);
    }

    await prefs.setStringList(
      _key,
      items.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> deleteListing(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    final items = raw
        .map((s) {
          try {
            return LivestockMarketListing.fromJson(
              jsonDecode(s) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<LivestockMarketListing>()
        .toList();

    items.removeWhere((e) => e.id == id);
    await prefs.setStringList(
      _key,
      items.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }
}

