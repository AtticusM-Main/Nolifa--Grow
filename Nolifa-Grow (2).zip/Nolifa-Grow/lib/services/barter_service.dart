import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/barter_listing.dart';

class BarterService {
  static const _key = 'barter_listings_v1';
  static const _seedKey = 'barter_seeded_v1';

  Future<List<BarterListing>> getListings() async {
    final prefs = await SharedPreferences.getInstance();
    final seeded = prefs.getBool(_seedKey) ?? false;
    if (!seeded) {
      final now = DateTime.now();
      final seedListings = [
        BarterListing(
          id: 'seed-1',
          offer: 'Chilli seedlings (10)',
          want: 'Compost or manure',
          notes: 'Pickup near taxi rank. Happy to swap.',
          contact: 'WhatsApp: 07x xxx xxxx',
          regionKey: 'greater_durban',
          languageCode: 'en',
          createdAt: now.subtract(const Duration(hours: 5)),
        ),
        BarterListing(
          id: 'seed-2',
          offer: 'Imbuya seeds',
          want: 'Spinach cuttings',
          notes: 'Small swaps welcome.',
          contact: 'SMS: 07x xxx xxxx',
          regionKey: 'zululand',
          languageCode: 'en',
          createdAt: now.subtract(const Duration(days: 1, hours: 2)),
        ),
        BarterListing(
          id: 'seed-3',
          offer: 'Aloe pups (2)',
          want: 'Any indigenous herbs',
          notes: 'Can meet at the community hall.',
          contact: 'Call: 07x xxx xxxx',
          regionKey: 'south_coast',
          languageCode: 'en',
          createdAt: now.subtract(const Duration(days: 2)),
        ),
      ];
      await prefs.setStringList(
        _key,
        seedListings.map((l) => jsonEncode(l.toJson())).toList(),
      );
      await prefs.setBool(_seedKey, true);
    }

    final raw = prefs.getStringList(_key) ?? const [];
    final listings = raw
        .map((s) {
          try {
            return BarterListing.fromJson(
              jsonDecode(s) as Map<String, dynamic>,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<BarterListing>()
        .toList();

    listings.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return listings;
  }

  Future<void> upsertListing(BarterListing listing) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];

    final parsed = <BarterListing>[];
    for (final item in raw) {
      try {
        parsed.add(
          BarterListing.fromJson(jsonDecode(item) as Map<String, dynamic>),
        );
      } catch (_) {}
    }

    final idx = parsed.indexWhere((l) => l.id == listing.id);
    if (idx >= 0) {
      parsed[idx] = listing;
    } else {
      parsed.add(listing);
    }

    parsed.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    await prefs.setStringList(
      _key,
      parsed.map((l) => jsonEncode(l.toJson())).toList(),
    );
  }

  Future<void> deleteListing(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];

    final kept = <String>[];
    for (final item in raw) {
      try {
        final listing = BarterListing.fromJson(
          jsonDecode(item) as Map<String, dynamic>,
        );
        if (listing.id != id) {
          kept.add(item);
        }
      } catch (_) {}
    }

    await prefs.setStringList(_key, kept);
  }
}
