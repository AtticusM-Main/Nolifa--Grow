import 'package:shared_preferences/shared_preferences.dart';

import '../models/diagnosis_record.dart';
import '../models/disease_info.dart';
import '../models/yield_prediction.dart';

class YieldPredictorService {
  static const _soilKey = 'yield_soil_v1';
  static const _humidityKey = 'yield_humidity_v1';
  static const _areaKey = 'yield_area_v1';
  static const _cropKey = 'yield_crop_v1';
  static const _priceKey = 'yield_price_v1';

  static const List<CropProfile> crops = [
    CropProfile(
      id: 'spinach',
      nameEn: 'Spinach',
      nameZu: 'Isipinashi',
      baseDaysToHarvest: 45,
      baseYieldKgPerM2: 2.5,
      recommendedPlantingMonths: {2, 3, 4, 5, 6, 7, 8, 9, 10, 11},
      diseaseSensitivity: 0.7,
    ),
    CropProfile(
      id: 'cabbage',
      nameEn: 'Cabbage',
      nameZu: 'Ikhabishi',
      baseDaysToHarvest: 95,
      baseYieldKgPerM2: 4.0,
      recommendedPlantingMonths: {3, 4, 5, 6, 7},
      diseaseSensitivity: 0.8,
    ),
    CropProfile(
      id: 'beans',
      nameEn: 'Beans',
      nameZu: 'Ubhontshisi',
      baseDaysToHarvest: 60,
      baseYieldKgPerM2: 1.8,
      recommendedPlantingMonths: {9, 10, 11, 12, 1, 2},
      diseaseSensitivity: 0.6,
    ),
    CropProfile(
      id: 'maize',
      nameEn: 'Maize',
      nameZu: 'Ummbila',
      baseDaysToHarvest: 120,
      baseYieldKgPerM2: 1.6,
      recommendedPlantingMonths: {10, 11, 12, 1},
      diseaseSensitivity: 0.5,
    ),
    CropProfile(
      id: 'tomato',
      nameEn: 'Tomato',
      nameZu: 'Utamatisi',
      baseDaysToHarvest: 85,
      baseYieldKgPerM2: 3.2,
      recommendedPlantingMonths: {8, 9, 10, 11, 12, 1},
      diseaseSensitivity: 1.0,
    ),
    CropProfile(
      id: 'chilli',
      nameEn: 'Chilli',
      nameZu: 'Upelepele',
      baseDaysToHarvest: 105,
      baseYieldKgPerM2: 2.0,
      recommendedPlantingMonths: {8, 9, 10, 11, 12, 1},
      diseaseSensitivity: 0.9,
    ),
    CropProfile(
      id: 'pumpkin',
      nameEn: 'Pumpkin',
      nameZu: 'Ithanga',
      baseDaysToHarvest: 110,
      baseYieldKgPerM2: 2.8,
      recommendedPlantingMonths: {9, 10, 11, 12},
      diseaseSensitivity: 0.7,
    ),
    CropProfile(
      id: 'imbuya',
      nameEn: 'Imbuya (Amaranth)',
      nameZu: 'Imbuya',
      baseDaysToHarvest: 50,
      baseYieldKgPerM2: 2.2,
      recommendedPlantingMonths: {9, 10, 11, 12, 1, 2, 3},
      diseaseSensitivity: 0.4,
    ),
  ];

  Future<(SoilType, HumidityLevel, double, String, double)> loadDefaults() async {
    final prefs = await SharedPreferences.getInstance();
    final soil = SoilType.values[prefs.getInt(_soilKey) ?? SoilType.loam.index];
    final humidity = HumidityLevel
        .values[prefs.getInt(_humidityKey) ?? HumidityLevel.medium.index];
    final area = prefs.getDouble(_areaKey) ?? 10.0;
    final cropId = prefs.getString(_cropKey) ?? crops.first.id;
    final price = prefs.getDouble(_priceKey) ?? 20.0;
    return (soil, humidity, area, cropId, price);
  }

  Future<void> saveDefaults({
    required SoilType soil,
    required HumidityLevel humidity,
    required double areaM2,
    required String cropId,
    required double pricePerKg,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_soilKey, soil.index);
    await prefs.setInt(_humidityKey, humidity.index);
    await prefs.setDouble(_areaKey, areaM2);
    await prefs.setString(_cropKey, cropId);
    await prefs.setDouble(_priceKey, pricePerKg);
  }

  YieldPredictionResult predict({
    required String cropId,
    required double areaM2,
    required SoilType soilType,
    required HumidityLevel humidity,
    required DateTime now,
    required List<DiagnosisRecord> history,
    DiseaseRiskLevel? overrideDiseaseRisk,
  }) {
    final crop = crops.firstWhere(
      (c) => c.id == cropId,
      orElse: () => crops.first,
    );

    final diseaseRisk =
        overrideDiseaseRisk ?? _estimateDiseaseRisk(now, humidity, history);
    final soilFactor = _soilFactor(soilType);
    final humidityFactor = _humidityFactor(humidity);
    final diseaseFactor = _diseaseFactor(diseaseRisk, crop.diseaseSensitivity);

    final days = (crop.baseDaysToHarvest *
            (1.05 - (soilFactor - 1.0) * 0.35) *
            (1.10 - (humidityFactor - 1.0) * 0.25) *
            (1.0 + _daysDiseasePenalty(diseaseRisk, crop.diseaseSensitivity)))
        .round()
        .clamp(20, 240);

    final yieldKg = crop.baseYieldKgPerM2 *
        areaM2 *
        soilFactor *
        humidityFactor *
        diseaseFactor;

    final recommended = recommendToPlantNow(
      now: now,
      soilType: soilType,
      humidity: humidity,
      history: history,
      overrideDiseaseRisk: overrideDiseaseRisk,
    );

    return YieldPredictionResult(
      crop: crop,
      areaM2: areaM2,
      soilType: soilType,
      humidity: humidity,
      diseaseRisk: diseaseRisk,
      estimatedDaysToHarvest: days,
      estimatedYieldKg: double.parse(yieldKg.toStringAsFixed(1)),
      recommendedToPlantNow: recommended,
    );
  }

  List<CropProfile> recommendToPlantNow({
    required DateTime now,
    required SoilType soilType,
    required HumidityLevel humidity,
    required List<DiagnosisRecord> history,
    DiseaseRiskLevel? overrideDiseaseRisk,
  }) {
    final diseaseRisk =
        overrideDiseaseRisk ?? _estimateDiseaseRisk(now, humidity, history);
    final month = now.month;

    final list = crops.where((c) => c.recommendedPlantingMonths.contains(month));
    final filtered = list.where((c) {
      if (diseaseRisk == DiseaseRiskLevel.high && c.diseaseSensitivity >= 0.9) {
        return false;
      }
      if (soilType == SoilType.clay && c.id == 'maize') {
        return false;
      }
      return true;
    }).toList();

    filtered.sort((a, b) {
      final scoreA = _recommendScore(a, soilType, humidity, diseaseRisk);
      final scoreB = _recommendScore(b, soilType, humidity, diseaseRisk);
      return scoreB.compareTo(scoreA);
    });

    return filtered.take(5).toList();
  }

  DiseaseRiskLevel _estimateDiseaseRisk(
    DateTime now,
    HumidityLevel humidity,
    List<DiagnosisRecord> history,
  ) {
    final recent = history.where((h) {
      final age = now.difference(h.date);
      return age.inDays <= 30;
    }).toList();

    var riskScore = 0.0;
    if (humidity == HumidityLevel.high) riskScore += 0.9;
    if (humidity == HumidityLevel.medium) riskScore += 0.45;

    for (final r in recent) {
      final info = DiseaseDatabase.getInfo(r.label);
      if (info.severityColor == 'red') {
        riskScore += 0.55;
      } else if (info.severityColor == 'orange') {
        riskScore += 0.3;
      }
    }

    if (riskScore >= 1.35) return DiseaseRiskLevel.high;
    if (riskScore >= 0.7) return DiseaseRiskLevel.medium;
    return DiseaseRiskLevel.low;
  }

  double _soilFactor(SoilType soil) {
    switch (soil) {
      case SoilType.sandy:
        return 0.88;
      case SoilType.loam:
        return 1.0;
      case SoilType.clay:
        return 0.9;
      case SoilType.coastalSand:
        return 0.84;
      case SoilType.alluvial:
        return 1.06;
    }
  }

  double _humidityFactor(HumidityLevel humidity) {
    switch (humidity) {
      case HumidityLevel.low:
        return 0.9;
      case HumidityLevel.medium:
        return 1.0;
      case HumidityLevel.high:
        return 0.95;
    }
  }

  double _diseaseFactor(DiseaseRiskLevel risk, double sensitivity) {
    switch (risk) {
      case DiseaseRiskLevel.low:
        return 1.0;
      case DiseaseRiskLevel.medium:
        return 1.0 - (0.12 * sensitivity);
      case DiseaseRiskLevel.high:
        return 1.0 - (0.25 * sensitivity);
    }
  }

  double _daysDiseasePenalty(DiseaseRiskLevel risk, double sensitivity) {
    switch (risk) {
      case DiseaseRiskLevel.low:
        return 0.0;
      case DiseaseRiskLevel.medium:
        return 0.06 * sensitivity;
      case DiseaseRiskLevel.high:
        return 0.14 * sensitivity;
    }
  }

  double _recommendScore(
    CropProfile crop,
    SoilType soilType,
    HumidityLevel humidity,
    DiseaseRiskLevel risk,
  ) {
    final soilFactor = _soilFactor(soilType);
    final humidityFactor = _humidityFactor(humidity);
    final diseaseFactor = _diseaseFactor(risk, crop.diseaseSensitivity);
    return crop.baseYieldKgPerM2 * soilFactor * humidityFactor * diseaseFactor;
  }
}
