import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/vet_request.dart';

class VetService {
  static const _key = 'vet_requests_v1';

  Future<List<VetRequest>> getRequests() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const [];
    final requests = raw
        .map((s) {
          try {
            return VetRequest.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<VetRequest>()
        .toList();
    requests.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return requests;
  }

  Future<void> submitRequest(VetRequest request) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    raw.insert(0, jsonEncode(request.toJson()));
    await prefs.setStringList(_key, raw);
  }
}

