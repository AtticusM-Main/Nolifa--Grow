class VetRequest {
  final String id;
  final String species;
  final String conditionKey;
  final String regionKey;
  final String notes;
  final DateTime createdAt;

  const VetRequest({
    required this.id,
    required this.species,
    required this.conditionKey,
    required this.regionKey,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'species': species,
      'conditionKey': conditionKey,
      'regionKey': regionKey,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory VetRequest.fromJson(Map<String, dynamic> json) {
    return VetRequest(
      id: json['id'] as String,
      species: (json['species'] as String?) ?? 'cattle',
      conditionKey: (json['conditionKey'] as String?) ?? 'healthy',
      regionKey: (json['regionKey'] as String?) ?? 'other',
      notes: (json['notes'] as String?) ?? '',
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}

