enum SoilType {
  sandy,
  loam,
  clay,
  coastalSand,
  alluvial,
}

enum HumidityLevel {
  low,
  medium,
  high,
}

enum DiseaseRiskLevel {
  low,
  medium,
  high,
}

class CropProfile {
  final String id;
  final String nameEn;
  final String nameZu;
  final int baseDaysToHarvest;
  final double baseYieldKgPerM2;
  final Set<int> recommendedPlantingMonths;
  final double diseaseSensitivity;

  const CropProfile({
    required this.id,
    required this.nameEn,
    required this.nameZu,
    required this.baseDaysToHarvest,
    required this.baseYieldKgPerM2,
    required this.recommendedPlantingMonths,
    required this.diseaseSensitivity,
  });
}

class YieldPredictionResult {
  final CropProfile crop;
  final double areaM2;
  final SoilType soilType;
  final HumidityLevel humidity;
  final DiseaseRiskLevel diseaseRisk;
  final int estimatedDaysToHarvest;
  final double estimatedYieldKg;
  final List<CropProfile> recommendedToPlantNow;

  const YieldPredictionResult({
    required this.crop,
    required this.areaM2,
    required this.soilType,
    required this.humidity,
    required this.diseaseRisk,
    required this.estimatedDaysToHarvest,
    required this.estimatedYieldKg,
    required this.recommendedToPlantNow,
  });
}

