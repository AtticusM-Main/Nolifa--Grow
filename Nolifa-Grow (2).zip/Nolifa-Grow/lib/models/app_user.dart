class AppUser {
  final String id;
  final String name;
  final String phone;
  final String pin;

  const AppUser({
    required this.id,
    required this.name,
    required this.phone,
    required this.pin,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'pin': pin,
    };
  }

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: (json['id'] as String?) ?? '',
      name: (json['name'] as String?) ?? '',
      phone: (json['phone'] as String?) ?? '',
      pin: (json['pin'] as String?) ?? '',
    );
  }
}

