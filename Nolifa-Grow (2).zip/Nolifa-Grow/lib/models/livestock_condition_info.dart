class LivestockConditionInfo {
  final String key;
  final String plainName;
  final String description;
  final String severity;
  final String severityColor;
  final List<String> signs;
  final List<String> treatment;
  final List<String> prevention;

  const LivestockConditionInfo({
    required this.key,
    required this.plainName,
    required this.description,
    required this.severity,
    required this.severityColor,
    required this.signs,
    required this.treatment,
    required this.prevention,
  });
}

class LivestockConditionDatabase {
  static const Map<String, LivestockConditionInfo> conditions = {
    'healthy': LivestockConditionInfo(
      key: 'healthy',
      plainName: 'No urgent concern detected',
      description:
          'Based on the signs selected, no urgent livestock condition stands out. Continue monitoring and ensure good nutrition, clean water, and shelter.',
      severity: 'Monitor',
      severityColor: 'green',
      signs: [
        'Normal appetite',
        'No discharge',
        'Normal droppings',
        'Normal movement',
      ],
      treatment: [
        'Keep clean water available at all times',
        'Maintain consistent feed',
        'Observe twice daily for changes',
      ],
      prevention: [
        'Vaccinate according to your local schedule',
        'Control parasites regularly',
        'Keep housing dry and well ventilated',
      ],
    ),
    'worms': LivestockConditionInfo(
      key: 'worms',
      plainName: 'Internal parasites (worms) likely',
      description:
          'Weight loss, diarrhoea, rough coat, or pale gums can indicate internal parasites. Worm burdens increase with grazing pressure and wet conditions.',
      severity: 'Act soon',
      severityColor: 'orange',
      signs: [
        'Diarrhoea',
        'Weight loss',
        'Rough coat',
        'Pale gums',
      ],
      treatment: [
        'Deworm using a livestock dewormer suitable for the species',
        'Ensure the animal is hydrated and has access to shade',
        'Separate weak animals so they can feed without competition',
      ],
      prevention: [
        'Rotate grazing areas if possible',
        'Avoid overstocking on small camps',
        'Deworm on a schedule guided by local extension advice',
      ],
    ),
    'mastitis': LivestockConditionInfo(
      key: 'mastitis',
      plainName: 'Mastitis (udder infection) suspected',
      description:
          'Swollen, hot, painful udder or clots in milk can indicate mastitis. It reduces milk yield and can spread between animals via milking hygiene.',
      severity: 'Urgent',
      severityColor: 'red',
      signs: [
        'Swollen udder',
        'Pain when touched',
        'Abnormal milk (clots, watery)',
        'Fever',
      ],
      treatment: [
        'Isolate the animal and milk out the affected quarter regularly',
        'Keep the udder clean and dry',
        'Contact a vet for appropriate antibiotic treatment',
      ],
      prevention: [
        'Clean hands and equipment before milking',
        'Disinfect teats after milking',
        'Keep bedding clean and dry',
      ],
    ),
    'foot_rot': LivestockConditionInfo(
      key: 'foot_rot',
      plainName: 'Foot rot / hoof infection suspected',
      description:
          'Lameness with a foul smell and swelling between the claws often points to foot rot. It worsens in muddy, wet conditions.',
      severity: 'Act soon',
      severityColor: 'orange',
      signs: [
        'Limping',
        'Swollen hoof',
        'Bad smell from hoof',
      ],
      treatment: [
        'Move animals to a dry area to reduce reinfection',
        'Clean the hoof and trim if needed',
        'Use a suitable hoof disinfectant or footbath if available',
        'Consult a vet if swelling/fever is present',
      ],
      prevention: [
        'Improve drainage in kraals and high-traffic areas',
        'Regular hoof inspection and trimming',
        'Footbath program in wet months',
      ],
    ),
    'tick_borne': LivestockConditionInfo(
      key: 'tick_borne',
      plainName: 'Tick-borne illness risk (fever + weakness)',
      description:
          'In KZN, tick pressure can lead to fever, weakness, and loss of appetite. Early treatment matters to prevent severe loss.',
      severity: 'Urgent',
      severityColor: 'red',
      signs: [
        'Fever',
        'Weakness',
        'Loss of appetite',
        'Ticks visible',
      ],
      treatment: [
        'Control ticks immediately using an approved acaricide',
        'Keep the animal cool and hydrated',
        'Contact a vet for diagnosis and treatment (e.g., anti-protozoal drugs)',
      ],
      prevention: [
        'Regular tick control during warm months',
        'Clear bushes around grazing areas where ticks thrive',
        'Check animals after grazing',
      ],
    ),
    'bloat': LivestockConditionInfo(
      key: 'bloat',
      plainName: 'Bloat suspected',
      description:
          'A swollen left abdomen and distress after grazing rich pasture can indicate bloat. This can become life-threatening quickly.',
      severity: 'Urgent',
      severityColor: 'red',
      signs: [
        'Swollen belly',
        'Difficulty breathing',
        'Restlessness',
      ],
      treatment: [
        'Remove from pasture and keep the animal walking if safe',
        'Call a vet urgently if breathing is affected',
        'Do not force liquids unless trained, as aspiration risk exists',
      ],
      prevention: [
        'Introduce animals slowly to lush pasture',
        'Avoid grazing wet legumes heavily',
        'Provide roughage before turnout',
      ],
    ),
    'newcastle': LivestockConditionInfo(
      key: 'newcastle',
      plainName: 'Newcastle disease suspected (poultry)',
      description:
          'Sneezing, green diarrhoea, sudden deaths, and nervous signs in chickens can indicate Newcastle disease. It spreads rapidly.',
      severity: 'Urgent',
      severityColor: 'red',
      signs: [
        'Sneezing/coughing',
        'Green diarrhoea',
        'Sudden deaths',
        'Twisted neck / nervous signs',
      ],
      treatment: [
        'Isolate sick birds immediately',
        'Disinfect housing and equipment',
        'Contact local animal health services for guidance',
      ],
      prevention: [
        'Vaccinate poultry on schedule',
        'Limit visitors to the coop',
        'Quarantine new birds for 14 days',
      ],
    ),
    'lumpy_skin': LivestockConditionInfo(
      key: 'lumpy_skin',
      plainName: 'Lumpy Skin Disease suspected (cattle)',
      description:
          'Firm skin nodules with fever and reduced feeding can suggest Lumpy Skin Disease. It is spread by biting insects and can reduce productivity.',
      severity: 'Urgent',
      severityColor: 'red',
      signs: [
        'Skin lumps/nodules',
        'Fever',
        'Swollen lymph nodes',
        'Reduced appetite',
      ],
      treatment: [
        'Isolate affected animals to reduce biting insect spread',
        'Control flies and mosquitoes around kraals',
        'Contact a vet for supportive care and secondary infection control',
      ],
      prevention: [
        'Vaccinate according to local guidance',
        'Insect control in warm, wet months',
        'Quarantine new animals',
      ],
    ),
  };

  static LivestockConditionInfo getInfo(String key) {
    return conditions[key] ?? conditions['healthy']!;
  }
}

