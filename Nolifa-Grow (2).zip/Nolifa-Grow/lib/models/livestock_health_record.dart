class LivestockHealthRecord {
  final String id;
  final String species;
  final String conditionKey;
  final String confidence;
  final List<String> symptoms;
  final String? notes;
  final DateTime date;
  final String? regionKey;

  const LivestockHealthRecord({
    required this.id,
    required this.species,
    required this.conditionKey,
    required this.confidence,
    required this.symptoms,
    required this.notes,
    required this.date,
    required this.regionKey,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'species': species,
      'conditionKey': conditionKey,
      'confidence': confidence,
      'symptoms': symptoms,
      'notes': notes,
      'date': date.toIso8601String(),
      'regionKey': regionKey,
    };
  }

  factory LivestockHealthRecord.fromMap(Map<String, dynamic> map) {
    return LivestockHealthRecord(
      id: map['id'] as String,
      species: (map['species'] as String?) ?? 'cattle',
      conditionKey: (map['conditionKey'] as String?) ?? 'healthy',
      confidence: (map['confidence'] as String?) ?? '0',
      symptoms: (map['symptoms'] as List?)?.whereType<String>().toList() ?? const [],
      notes: map['notes'] as String?,
      date: DateTime.tryParse((map['date'] as String?) ?? '') ?? DateTime.now(),
      regionKey: map['regionKey'] as String?,
    );
  }
}

