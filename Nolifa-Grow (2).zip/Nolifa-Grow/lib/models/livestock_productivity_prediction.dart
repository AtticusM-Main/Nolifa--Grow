class LivestockProductivityPrediction {
  final String headline;
  final String riskLevel;
  final String riskColor;
  final int daysToMarket;
  final double expectedGainKg;
  final double expectedRevenue;
  final List<String> recommendations;

  const LivestockProductivityPrediction({
    required this.headline,
    required this.riskLevel,
    required this.riskColor,
    required this.daysToMarket,
    required this.expectedGainKg,
    required this.expectedRevenue,
    required this.recommendations,
  });
}

