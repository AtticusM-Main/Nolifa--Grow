class PlantSpecies {
  final String id;
  final String commonNameEn;
  final String commonNameZu;
  final String? scientificName;
  final String descriptionEn;
  final String descriptionZu;
  final List<String> usesEn;
  final List<String> usesZu;
  final List<String> cautionsEn;
  final List<String> cautionsZu;
  final List<String> tags;

  const PlantSpecies({
    required this.id,
    required this.commonNameEn,
    required this.commonNameZu,
    required this.descriptionEn,
    required this.descriptionZu,
    required this.usesEn,
    required this.usesZu,
    required this.cautionsEn,
    required this.cautionsZu,
    required this.tags,
    this.scientificName,
  });

  factory PlantSpecies.fromJson(Map<String, dynamic> json) {
    return PlantSpecies(
      id: json['id'] as String,
      commonNameEn: (json['commonNameEn'] as String?) ?? '',
      commonNameZu: (json['commonNameZu'] as String?) ?? '',
      scientificName: json['scientificName'] as String?,
      descriptionEn: (json['descriptionEn'] as String?) ?? '',
      descriptionZu: (json['descriptionZu'] as String?) ?? '',
      usesEn: ((json['usesEn'] as List?) ?? const [])
          .whereType<String>()
          .toList(),
      usesZu: ((json['usesZu'] as List?) ?? const [])
          .whereType<String>()
          .toList(),
      cautionsEn: ((json['cautionsEn'] as List?) ?? const [])
          .whereType<String>()
          .toList(),
      cautionsZu: ((json['cautionsZu'] as List?) ?? const [])
          .whereType<String>()
          .toList(),
      tags: ((json['tags'] as List?) ?? const []).whereType<String>().toList(),
    );
  }
}

