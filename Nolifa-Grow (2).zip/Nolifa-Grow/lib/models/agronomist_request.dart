class AgronomistRequest {
  final String id;
  final String name;
  final String contact;
  final String? regionKey;
  final String message;
  final String? diagnosisLabel;
  final String? diagnosisConfidence;
  final String? imagePath;
  final DateTime createdAt;

  const AgronomistRequest({
    required this.id,
    required this.name,
    required this.contact,
    required this.message,
    required this.createdAt,
    this.regionKey,
    this.diagnosisLabel,
    this.diagnosisConfidence,
    this.imagePath,
  });

  factory AgronomistRequest.fromJson(Map<String, dynamic> json) {
    return AgronomistRequest(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      contact: (json['contact'] as String?) ?? '',
      regionKey: json['regionKey'] as String?,
      message: (json['message'] as String?) ?? '',
      diagnosisLabel: json['diagnosisLabel'] as String?,
      diagnosisConfidence: json['diagnosisConfidence'] as String?,
      imagePath: json['imagePath'] as String?,
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'contact': contact,
      'regionKey': regionKey,
      'message': message,
      'diagnosisLabel': diagnosisLabel,
      'diagnosisConfidence': diagnosisConfidence,
      'imagePath': imagePath,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}

