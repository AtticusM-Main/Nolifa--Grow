class LivestockMarketListing {
  final String id;
  final String title;
  final String species;
  final String listingType;
  final String description;
  final String regionKey;
  final DateTime createdAt;

  const LivestockMarketListing({
    required this.id,
    required this.title,
    required this.species,
    required this.listingType,
    required this.description,
    required this.regionKey,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'species': species,
      'listingType': listingType,
      'description': description,
      'regionKey': regionKey,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory LivestockMarketListing.fromJson(Map<String, dynamic> json) {
    return LivestockMarketListing(
      id: json['id'] as String,
      title: (json['title'] as String?) ?? '',
      species: (json['species'] as String?) ?? 'cattle',
      listingType: (json['listingType'] as String?) ?? 'offer',
      description: (json['description'] as String?) ?? '',
      regionKey: (json['regionKey'] as String?) ?? 'other',
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}

