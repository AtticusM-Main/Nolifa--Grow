class BarterListing {
  final String id;
  final String offer;
  final String want;
  final String? notes;
  final String? contact;
  final String? regionKey;
  final String languageCode;
  final DateTime createdAt;

  const BarterListing({
    required this.id,
    required this.offer,
    required this.want,
    required this.languageCode,
    required this.createdAt,
    this.notes,
    this.contact,
    this.regionKey,
  });

  factory BarterListing.fromJson(Map<String, dynamic> json) {
    return BarterListing(
      id: json['id'] as String,
      offer: (json['offer'] as String?) ?? '',
      want: (json['want'] as String?) ?? '',
      notes: json['notes'] as String?,
      contact: json['contact'] as String?,
      regionKey: json['regionKey'] as String?,
      languageCode: (json['languageCode'] as String?) ?? 'en',
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'offer': offer,
      'want': want,
      'notes': notes,
      'contact': contact,
      'regionKey': regionKey,
      'languageCode': languageCode,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}

