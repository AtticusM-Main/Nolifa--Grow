class ChatMessage {
  final String id;
  final String threadId;
  final String text;
  final bool fromMe;
  final DateTime createdAt;

  const ChatMessage({
    required this.id,
    required this.threadId,
    required this.text,
    required this.fromMe,
    required this.createdAt,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] as String,
      threadId: json['threadId'] as String,
      text: (json['text'] as String?) ?? '',
      fromMe: (json['fromMe'] as bool?) ?? false,
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'threadId': threadId,
      'text': text,
      'fromMe': fromMe,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}

