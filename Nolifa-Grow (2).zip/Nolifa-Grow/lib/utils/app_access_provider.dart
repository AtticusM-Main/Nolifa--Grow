import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/app_access_service.dart';
import 'auth_provider.dart';

final appAccessProvider =
    StateNotifierProvider<AppAccessNotifier, AppAccess?>((ref) {
  return AppAccessNotifier(
    ref: ref,
    service: AppAccessService(),
  );
});

class AppAccessNotifier extends StateNotifier<AppAccess?> {
  final Ref ref;
  final AppAccessService service;

  AppAccessNotifier({
    required this.ref,
    required this.service,
  }) : super(null) {
    ref.listen(authProvider, (_, __) => _load());
    _load();
  }

  Future<void> _load() async {
    final user = ref.read(authProvider).user;
    if (user == null) {
      state = null;
      return;
    }
    state = await service.getAccess(user.id);
  }

  Future<void> setAccess(AppAccess access) async {
    final user = ref.read(authProvider).user;
    if (user == null) return;
    state = access;
    await service.setAccess(user.id, access);
  }
}

