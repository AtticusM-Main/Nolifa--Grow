import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_user.dart';
import '../services/auth_service.dart';

class AuthState {
  final bool loading;
  final AppUser? user;

  const AuthState({required this.loading, required this.user});

  bool get isLoggedIn => user != null;
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(AuthService());
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthService _service;

  AuthNotifier(this._service) : super(const AuthState(loading: true, user: null)) {
    _load();
  }

  Future<void> _load() async {
    final user = await _service.getCurrentUser();
    state = AuthState(loading: false, user: user);
  }

  Future<void> login({required String phone, required String pin}) async {
    state = AuthState(loading: true, user: state.user);
    final user = await _service.login(phone: phone, pin: pin);
    state = AuthState(loading: false, user: user);
  }

  Future<void> register({
    required String name,
    required String phone,
    required String pin,
  }) async {
    state = AuthState(loading: true, user: state.user);
    final user = await _service.register(name: name, phone: phone, pin: pin);
    state = AuthState(loading: false, user: user);
  }

  Future<void> logout() async {
    await _service.logout();
    state = const AuthState(loading: false, user: null);
  }
}

