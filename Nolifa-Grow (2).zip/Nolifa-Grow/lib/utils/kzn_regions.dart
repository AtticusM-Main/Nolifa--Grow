import 'translations.dart';

class KznRegions {
  static const List<String> keys = [
    'greater_durban',
    'midlands',
    'north_coast',
    'south_coast',
    'zululand',
    'northern_kzn',
    'other',
  ];

  static String label(String regionKey, String lang) {
    return AppTranslations.get(regionKey, lang);
  }
}

