import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_access_provider.dart';
import 'auth_provider.dart';

enum AppMode {
  plants,
  livestock,
}

final appModeProvider = StateNotifierProvider<AppModeNotifier, AppMode>((ref) {
  return AppModeNotifier(ref: ref);
});

class AppModeNotifier extends StateNotifier<AppMode> {
  final Ref ref;

  AppModeNotifier({required this.ref}) : super(AppMode.plants) {
    ref.listen(authProvider, (_, __) => _load());
    ref.listen(appAccessProvider, (_, __) => _enforceAccess());
    _load();
  }

  String _keyFor(String userId) => 'app_mode_v1_$userId';

  Future<void> _load() async {
    final user = ref.read(authProvider).user;
    if (user == null) {
      state = AppMode.plants;
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyFor(user.id));
    state = raw == 'livestock' ? AppMode.livestock : AppMode.plants;
    _enforceAccess();
  }

  Future<void> setMode(AppMode mode) async {
    final access = ref.read(appAccessProvider);
    if (access == AppAccess.plantsOnly) {
      state = AppMode.plants;
      return;
    }
    if (access == AppAccess.livestockOnly) {
      state = AppMode.livestock;
      return;
    }

    state = mode;
    final user = ref.read(authProvider).user;
    if (user == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _keyFor(user.id),
      mode == AppMode.livestock ? 'livestock' : 'plants',
    );
  }

  void _enforceAccess() {
    final access = ref.read(appAccessProvider);
    if (access == AppAccess.plantsOnly && state != AppMode.plants) {
      state = AppMode.plants;
    }
    if (access == AppAccess.livestockOnly && state != AppMode.livestock) {
      state = AppMode.livestock;
    }
  }
}
